<?php
session_start();
include_once('../connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - Fast aid Guide</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link href="fastaidSearch.css" rel="stylesheet" type="text/css">
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>

</head>

<body>
    <!-- Add the top navigation here -->

    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>

    <header>
        <div class="logo">
            <a href="index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="../EmergencyRequest/emergency_request_form.php">Need Help</a></li>\
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <div class="bgSearch">
        <div class="searchTitle">Results for Emergency Treatment</div>

        <form action="fastaidSearch.php" method="post">
            <input type="text" name="as" placeholder="enter your queries ..." value="<?php echo htmlspecialchars($_POST['as'] ?? ''); ?>" id="searchBox" required>
            <input type="submit" value="Search" id="searchButton">
        </form>
    </div>

    <div id="results">

        <?php
        // ambulanceSearch.php

        // Establish a connection to the MySQL database using mysqli
        $host = "localhost";
        $username = "root";
        $password = "";
        $database = "quickresq";

        $conn = new mysqli($host, $username, $password, $database);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Sanitize user input (avoid SQL injection)
        $searchq = $conn->real_escape_string($_POST['as'] ?? '');

        // Prepare and execute the SQL query
        $query = "SELECT * FROM  first_aid_topics WHERE topic LIKE '%$searchq%'";
        $result = $conn->query($query);

        if ($result->num_rows === 0) {
            echo "<p>No results found. Please enter a valid reason (e.g., 'flu').</p>";
        } else {
            while ($row = $result->fetch_assoc()) {
                $topic = $row['topic'];
                $instructions = $row['instructions'];
               

                echo "<div id='result'>";
                echo "<h2><b>$topic</b></h2>";
                echo "<p><b>Instructions:</b> <br>$instructions</p>";
                echo "<hr />";
                echo "</div>";
            }
        }

        // Close the database connection
        $conn->close();
        ?>

    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email:quickresq@info.org.bd</p>
                <p>Phone:+123 456 789</p>
                <p>Address:B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>

    </footer>
</body>

</html>