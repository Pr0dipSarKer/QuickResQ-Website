<?php
session_start();
include("connection.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Something was posted
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if (!empty($user_name) && !empty($password) && !is_numeric($user_name)) {
        // Read from the database
        $query = "SELECT * FROM admin WHERE user_name = '$user_name' LIMIT 1";
        $result = mysqli_query($con, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            $user_data = mysqli_fetch_assoc($result);
            if ($user_data['password'] === $password) {
                // Correct credentials, redirect to admin_home.php
                $_SESSION['user_id'] = $user_data['user_id'];
                header("Location: admin_home.php");
                die; // Ensure no further execution after redirection
            }
        }
        // Incorrect credentials, show error message
        echo "<script>alert('Wrong username or password!');</script>";

    } else {
        // Invalid input, show error message
        echo "<script>alert('Invalid input!');</script>";
    }
}
?>



<style>


/* Center the login form */
#box {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 350px; /* Adjust the size as needed */
    height: 250px;
    position: relative; /* Add this line */
    box-sizing: border-box;
    background-color:powderblue;
    border-radius: 5px;
    top: 200px;
    left: 750px;
    padding-left: 10px;
    padding-right: 10px;
}

/* Style the form title */
.form-title {
    font-size: 20px;
    text-align: center;
    color: black;
    
}

/* Style the input fields */
input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* Style the login button */
input[type="submit"] {
    background-color:cadetblue;
    color: black;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    font-family: 'Courier New', Courier, monospace;
    font-weight: bold;
}



/* Style the logo */
.logo {
    position: absolute;
    top: 20px;
    left: 20px;
    width: 150px; /* Adjust the size as needed */
    height: 75px;
}

/* Style the admin image */
.admin-image {
    position: absolute;
    align-items: left;
    width: 300px; /* Adjust the size as needed */
    height: 250px;
    top: 208px;
    left: 450px;
    border-radius: 5px;
}


</style>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon"/>
    <title>QuickResQ - Admin Login</title>
</head>
<body>
    <div>
        <img src="../Image/QuickResQ_logo.png" alt="Website Logo" class="logo">
    </div>
    <div id="admin-image">
        <img src="../Image/admin.png" alt="Admin Image" class="admin-image"> <!-- Add your admin image here -->
    </div>
    <div id="box">
        <form method="post">
            <div class="form-title">Admin Login</div><br>
            <label>USERNAME</label>
            <input type="text" name="user_name" placeholder="User name" required>
            <label>PASSWORD</label>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>