<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - ADMIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="Admin_CSS/admin_fastaid.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="..." crossorigin="anonymous" />
</head>

<body>
    <header>
        <div class="topnav">
            <h5 style="align-items: center;">Emergency Support System</h5>
        </div>

        <div class="logo">
            <a href="admin_home.php">
                <img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo">
            </a>
        </div>
        <div id="buttonStyle">
            <ul>
                <li><a href="admin_hospital.php">Hospital</a></li>
                <li><a href="admin_ambulance.php">Ambulance</a></li>
                <li><a href="admin_findblood.php">Find Blood</a></li>
                <li><a href="admin_fireservice.php">Fire Service</a></li>
                <li><a href="admin_policestation.php">Police</a></li>
                <li><a href="admin_volunteer.php">Volunteer</a></li>
                <li><a href="admin_fastaid.php">Fastaid</a></li>
                <li><a href="admin_erequest.php">E-Request</a></li>
                <li><a href="admin_incidentReports.php">Incidents</a></li>
                <a href="admin_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </ul>
        </div>
    </header>

    <?php
    session_start();
    include("connection.php");
    ?>
    <?php
    $conn = mysqli_connect('localhost', 'root', '', 'quickresq');

    if (isset($_POST["submit1"])) {
        $sql = "INSERT INTO first_aid_topics(topic , instructions)
    VALUES('$_POST[topic]','$_POST[instructions]')";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully INSERT')</script>";
            header('Location: admin_fastaid.php');
            exit();
        }
    }

    if (isset($_POST["submit2"])) {
        $sql = "DELETE FROM first_aid_topics WHERE topic='$_POST[topic]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully DELETE')</script>";
            header('Location: admin_fastaid.php');
            exit();
        }
    }

    if (isset($_POST["submit3"])) {
        $sql = "UPDATE first_aid_topics SET  topic='$_POST[topic]', instructions='$_POST[instructions]' WHERE topic= '$_POST[topic]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully UPDATE')</script>";
            header('Location: admin_fastaid.php');
            exit();
        }
    }
    ?>


    <div id="box1">
        <form method="post">
            <div style="font-size: 20px; font-weight:bold; margin-bottom: 10px; color: black; text-align:center;">Fast Aid</div>
            <div class="form-group">
                <label for="topic">Treatment Name</label><br>
                <input id="topic" type="text" name="topic" required><br>
            </div>
            <div class="form-group">
                <label for="instructions">instructions</label> <br>
                <input id="instructions" type="text" name="instructions"><br>
            </div>

            <div class="btn-group">
                <input type="submit" value="INSERT" name="submit1">
                <input type="submit" value="DELETE" name="submit2">
                <input type="submit" value="UPDATE" name="submit3">
            </div>
        </form>
    </div>


    <div id="search-container">
        <form>
            <input type="text" id="search_query" name="search_query" placeholder="Search by emergency treatment name ...">
        </form>
    </div>

    <div>
        <table border="1" cellspacing="1" cellpadding="10" id="search-table">
            <tr>
                <th>ID</th>
                <th>Treatment Name</th>
                <th>Instructions</th>
            </tr>
            <?php
            $conn = mysqli_connect("localhost", "root", "", "quickresq");

            $sql = "SELECT * FROM first_aid_topics";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["id"] . "</td><td>" . $row["topic"] . "</td><td>" . $row["instructions"] .  "</td></tr>";
                }
            } else {
                echo "<tr><td colspan='7'>0 results</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </div>

    <script>
        document.getElementById("search_query").addEventListener("input", function() {
            var input = this.value.toLowerCase();
            var table = document.getElementById("search-table");
            var rows = table.getElementsByTagName("tr");
            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName("td");
                var found = false;
                for (var j = 1; j < cells.length; j++) {
                    var cellText = cells[j].textContent || cells[j].innerText;
                    if (cellText.toLowerCase().indexOf(input) > -1) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        });
    </script>
</body>

</html>