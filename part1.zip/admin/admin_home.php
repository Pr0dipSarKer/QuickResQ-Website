<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "quickresq");

// Array of table names
$tables = array("ambulancedatabase", "hospitaldatabase", "bloodbankdatabase", "fireservicesdatabase", "policestationdatabase", "volunteer");

// Function to get total rows in a table
function getTotalRows($conn, $table) {
    $sql = "SELECT COUNT(*) as total_rows FROM $table";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total_rows'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>QuickResQ - ADMIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="..." crossorigin="anonymous" />
</head>
<body>
    <header>
        <div class="topnav">
            <h5 style="align-items: center;">Emergency Support System</h5>
        </div>
        <header>
            <div class="logo">
                <a href="admin_home.php">
                    <img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo">
                </a>
            </div>
            <div id="buttonStyle">
                <ul>
                    <li><a href="admin_hospital.php">Hospital</a></li>
                    <li><a href="admin_ambulance.php">Ambulance</a></li>
                    <li><a href="admin_findblood.php">Find Blood</a></li>
                    <li><a href="admin_fireservice.php">Fire Service</a></li>
                    <li><a href="admin_policestation.php">Police</a></li>
                    <li><a href="admin_volunteer.php">Volunteer</a></li>
                    <li><a href="admin_fastaid.php">Fastaid</a></li>
                    <li><a href="admin_erequest.php">E-Request</a></li>
                    <li><a href="admin_incidentReports.php">Incidents</a></li>
                    <a href="admin_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
                </ul>
            </div>
    </header>
    
    <div class="welcome-container">
        <img src="../Image/admin_welcome.gif" alt="Welcome Admin" class="welcome-gif">
        <p class="welcome-note">Welcome HOME <br><br>Admin!</p>
    </div>

    <div class="cards-container">
        <?php foreach($tables as $table): ?>
            <div class="card">
                <div class="circle"><?php echo getTotalRows($conn, $table); ?></div>
                <div class="card-text"><?php echo ucfirst(str_replace("database", "", $table)); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>


<style>
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    overflow-x: hidden;
}

/* Header Start */
.topnav {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 25px;
    background-color: red;
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.topnav h5 {
    color: white;
    margin: 0;
    letter-spacing: 5px;
    word-spacing: 10px;
}

.logo {
    height: 70px;
    width: 150px;
    margin-top: 30px;
    margin-left: 20px;
    border-radius: 8px;
}

#buttonStyle {
    position: absolute;
    right: 70px;
    top: 60px;
}

#buttonStyle ul {
    list-style: none;
}

#buttonStyle ul li {
    background-color: #fc006d;
    border-radius: 3px;
    margin-left: 10px;
    width: 100px;
    height: 30px;
    text-align: center;
    line-height: 30px;
    float: left;
    font-family: Arial;
    box-shadow: 0px 4px 0px 0px #e20464;
    position: relative;
}

#buttonStyle ul li a {
    font-size: 16px;
    font-weight: bold;
    text-decoration: none;
    color: white;
    display: block;
}

#buttonStyle ul li a:hover {
    color: #007dc1;
    background-color: #ededed;
    border-radius: 2px;
    box-shadow: 0px 4px 0px 0px #c62828;
}

.logout-btn {
    text-decoration: none;
    color:#e20464; /* Change the color as needed */
    float: right; /* Float the logout button to the right */
}

.logout-btn:hover {
    color:#c62828; /* Change the color as needed */
}

/* Additional styling for the icon */
.logout-btn i {
    margin-top: 10px;
    margin-left: 20px;

}





/* New Styles */

.welcome-container {
    display: flex;
    background-color:seashell;
    align-items: center;
    margin-top: 120px; /* Adjust margin as needed */
    margin-left: 500px;
    height: 280px;
    width: 550px;
    
}

.welcome-gif {
    height: 280px;
    width: 300px; /* Adjust width as needed */
    margin-right: 50px; /* Adjust margin as needed */
}

.welcome-note {
    font-size: 25px;
    font-weight: bold;
    font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    font-style: italic;
    color:crimson;
    text-align: center;
    

}

.cards-container {
    display: flex;
    justify-content: space-around;
    margin-top: 50px;
}

.card {
    text-align: center;
}

.circle {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background-color:#fc006d;
    color: white;
    font-size: 40px;
    line-height: 100px;
    margin: 0 auto 10px auto;
}

.card-text {
    font-size: 20px;
}
</style>

