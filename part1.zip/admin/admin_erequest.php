<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - ADMIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="Admin_CSS/admin_erequest.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="..." crossorigin="anonymous" />
</head>

<body>
    <header>
        <div class="topnav">
            <h5 style="align-items: center;">Emergency Support System</h5>
        </div>

        <div class="logo">
            <a href="admin_home.php">
                <img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo">
            </a>
        </div>
        <div id="buttonStyle">
            <ul>
                <li><a href="admin_hospital.php">Hospital</a></li>
                <li><a href="admin_ambulance.php">Ambulance</a></li>
                <li><a href="admin_findblood.php">Find Blood</a></li>
                <li><a href="admin_fireservice.php">Fire Service</a></li>
                <li><a href="admin_policestation.php">Police</a></li>
                <li><a href="admin_volunteer.php">Volunteer</a></li>
                <li><a href="admin_fastaid.php">Fastaid</a></li>
                <li><a href="admin_erequest.php">E-Request</a></li>
                <li><a href="admin_incidentReports.php">Incidents</a></li>
                <a href="admin_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </ul>
        </div>
    </header>

    <?php
    session_start();
    include("connection.php");
    ?>
    <?php
    $conn = mysqli_connect('localhost', 'root', '', 'quickresq');

    if (isset($_POST["submit1"])) {
        $sql = "INSERT INTO emergency_requests(name , phone , location , incident_details , created_at , solved)
    VALUES('$_POST[name]','$_POST[phone]', '$_POST[location]', '$_POST[incident_details]', '$_POST[created_at]', '$_POST[solved]')";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully INSERT')</script>";
            header('Location: admin_erequest.php');
            exit();
        }
    }

    if (isset($_POST["submit2"])) {
        $sql = "DELETE FROM emergency_requests WHERE name='$_POST[name]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully DELETE')</script>";
            header('Location: admin_erequest.php');
            exit();
        }
    }

    if (isset($_POST["submit3"])) {
        $sql = "UPDATE emergency_requests SET  name='$_POST[name]', phone='$_POST[phone]', location='$_POST[location]', incident_details='$_POST[incident_details]', created_at='$_POST[created_at]', solved='$_POST[solved]' WHERE name= '$_POST[name]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully UPDATE')</script>";
            header('Location: admin_erequest.php');
            exit();
        }
    }
    ?>


    <div id="box1">
        <form method="post">
            <div style="font-size: 20px; font-weight:bold; margin-bottom: 10px; color: black; text-align:center;">Emergency Request</div>
            <div class="form-group">
                <label for="name">Name</label><br>
                <input id="name" type="text" name="name" required><br>
            </div>
            <div class="form-group">
                <label for="phone">Phone</label> <br>
                <input id="phone" type="text" name="phone"><br>
            </div>
            <div class="form-group">
                <label for="location">Location</label><br>
                <input id="location" type="text" name="location"><br>
            </div>
            <div class="form-group">
                <label for="incident_details">Incident Details</label><br>
                <input id="incident_details" type="text" name="incident_details"><br>
            </div>
            <div class="form-group">
                <label for="created_at">Request Time</label><br>
                <input id="created_at" type="text" name="created_at"><br>
            </div>
            <div class="form-group">
                <label for="solved">Solved</label><br>
                <input id="solved" type="text" name="solved"><br>
            </div>

            <div class="btn-group">
                <input type="submit" value="INSERT" name="submit1">
                <input type="submit" value="DELETE" name="submit2">
                <input type="submit" value="UPDATE" name="submit3">
            </div>
        </form>
    </div>


    <div id="search-container">
        <form>
            <input type="text" id="search_query" name="search_query" placeholder="Search by name,  phone number, or solveds">
        </form>
    </div>

    <div>
        <table border="1" cellspacing="1" cellpadding="10" id="search-table">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Location</th>
                <th>Incident Details</th>
                <th>Request Time</th>
                <th>Status</th> <!-- Add a new column for status -->
                <?php
                $conn = mysqli_connect("localhost", "root", "", "quickresq");

                $sql = "SELECT id, name, phone, address, incident_details, created_at, solved FROM emergency_requests";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["id"] . "</td><td>" . $row["name"] . "</td><td>" . $row["phone"] . "</td><td>" . $row["address"] . "</td><td>" . $row["incident_details"] . "</td><td>" . $row["created_at"] . "</td>";

                        // Display button to mark the request as solved or unsolved
                        echo "<td>";
                        if ($row["solved"] == 1) {
                            echo "<button onclick='markAsUnsolved(" . $row["id"] . ")'>Unsolved</button>";
                        } else {
                            echo "<button onclick='markAsSolved(" . $row["id"] . ")'>Solved</button>";
                        }
                        echo "</td>";

                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>0 results</td></tr>";
                }
                $conn->close();
                ?>
        </table>
    </div>

    <script>
        document.getElementById("search_query").addEventListener("input", function() {
            var input = this.value.toLowerCase();
            var table = document.getElementById("search-table");
            var rows = table.getElementsByTagName("tr");
            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName("td");
                var found = false;
                for (var j = 1; j < cells.length; j++) {
                    var cellText = cells[j].textContent || cells[j].innerText;
                    if (cellText.toLowerCase().indexOf(input) > -1) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        });
    </script>
    <script>
        function markAsSolved(id) {
            if (confirm('Are you sure you want to mark this request as solved?')) {
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        location.reload(); // Reload the page after successful update
                    }
                };
                xhttp.open("POST", "update_status.php", true);
                xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhttp.send("id=" + id + "&solved=1"); // Send request to mark as solved
            }
        }

        function markAsUnsolved(id) {
            if (confirm('Are you sure you want to mark this request as unsolved?')) {
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        location.reload(); // Reload the page after successful update
                    }
                };
                xhttp.open("POST", "update_status.php", true);
                xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhttp.send("id=" + id + "&solved=0"); // Send request to mark as unsolved
            }
        }
    </script>
</body>

</html>