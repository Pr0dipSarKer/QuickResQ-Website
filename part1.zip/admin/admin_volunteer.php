<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - ADMIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="Admin_CSS/admin_volunteer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="..." crossorigin="anonymous" />
</head>

<body>
    <header>
        <div class="topnav">
            <h5 style="align-items: center;">Emergency Support System</h5>
        </div>

        <div class="logo">
            <a href="admin_home.php">
                <img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo">
            </a>
        </div>
        <div id="buttonStyle">
            <ul>
                <li><a href="admin_hospital.php">Hospital</a></li>
                <li><a href="admin_ambulance.php">Ambulance</a></li>
                <li><a href="admin_findblood.php">Find Blood</a></li>
                <li><a href="admin_fireservice.php">Fire Service</a></li>
                <li><a href="admin_policestation.php">Police</a></li>
                <li><a href="admin_volunteer.php">Volunteer</a></li>
                <li><a href="admin_fastaid.php">Fastaid</a></li>
                <li><a href="admin_erequest.php">E-Request</a></li>
                <li><a href="admin_incidentReports.php">Incidents</a></li>
                <a href="admin_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </ul>
        </div>
    </header>

    <?php
    session_start();
    include("connection.php");
    ?>
    <?php
    $conn = mysqli_connect('localhost', 'root', '', 'quickresq');

    // Check if the form is submitted
    if (isset($_POST["submit1"])) {
        // File Upload Directory
        $target_dir = "../QuickResQ/Volunteer/uploads";

        // Check if the directory exists and is writable
        if (!is_dir($target_dir) || !is_writable($target_dir)) {
            echo "Upload directory does not exist or is not writable.";
            exit(); // Stop further execution
        }

        // File Upload Errors
        if ($_FILES["image"]["error"] !== UPLOAD_ERR_OK) {
            echo "File upload failed with error code: " . $_FILES["image"]["error"];
            exit(); // Stop further execution
        }

        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        $allowedFormats = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType, $allowedFormats)) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            // Try to upload file
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                // File uploaded successfully, now insert into database
                $image = basename($_FILES["image"]["name"]);
                $name = $_POST["name"];
                $address = $_POST["address"];
                $phoneNum = $_POST["phoneNum"];
                $blood_group = $_POST["blood_group"];
                $keywords = $_POST["keywords"];

                $sql = "INSERT INTO volunteer (image, name, address, phoneNum, blood_group, keywords) 
                    VALUES ('$image', '$name', '$address', '$phoneNum', '$blood_group', '$keywords')";
                if ($conn->query($sql) === true) {
                    echo "<script>alert('Successfully INSERT')</script>";
                    header('Location: admin_volunteer.php');
                    exit();
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }

    if (isset($_POST["submit2"])) {
        $sql = "DELETE FROM volunteer WHERE name='$_POST[name]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully DELETE')</script>";
            header('Location: admin_volunteer.php');
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }


    if (isset($_POST["submit3"])) {
        $sql = "UPDATE volunteer SET  image='$_POST[image]', name='$_POST[name]', address='$_POST[address]', phoneNum='$_POST[phoneNum]', blood_group='$_POST[blood_group]', keywords='$_POST[keywords]' WHERE name= '$_POST[name]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully UPDATE')</script>";
            header('Location: admin_volunteer.php');
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>


    <div id="box1">
        <form method="post" enctype="multipart/form-data">
            <div style="font-size: 20px; font-weight:bold; margin-bottom: 10px; color: black; text-align:center;">Volunteer</div>
            <div class="form-group">
                <label for="image">Image</label><br>
                <input id="image" type="file" name="image" required accept="image/*"><br>
            </div>
            <div class="form-group">
                <label for="name">Name</label><br>
                <input id="name" type="text" name="name" required><br>
            </div>
            <div class="form-group">
                <label for="address">Address</label> <br>
                <input id="address" type="text" name="address"><br>
            </div>
            <div class="form-group">
                <label for="phoneNum">Phone Number</label><br>
                <input id="phoneNum" type="text" name="phoneNum"><br>
            </div>
            <div class="form-group">
                <label for="blood_group">Blood Group</label><br>
                <input id="blood_group" type="text" name="blood_group"><br>
            </div>
            <div class="form-group">
                <label for="keywords">Keywords</label><br>
                <input id="keywords" type="text" name="keywords"><br>
            </div>

            <div class="btn-group">
                <input type="submit" value="INSERT" name="submit1">
                <input type="submit" value="DELETE" name="submit2">
                <input type="submit" value="UPDATE" name="submit3">
            </div>
        </form>
    </div>


    <div id="search-container">
        <form>
            <input type="text" id="search_query" name="search_query" placeholder="Search by name, address, phone number, blood group, or keywords">
        </form>
    </div>

    <div>
        <table border="1" cellspacing="1" cellpadding="10" id="search-table">
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Address</th>
                <th>Phone Number</th>
                <th>Blood Group</th>
                <th>Keywords</th>
            </tr>
            <?php
            $conn = mysqli_connect("localhost", "root", "", "quickresq");

            $sql = "SELECT id, image, name, address, phoneNum, blood_group, keywords FROM volunteer";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Adjust the image path to include the 'uploads/' directory
                    echo "<tr><td>" . $row["id"] . "</td><td><img src='uploads/" . $row["image"] . "' alt='Volunteer Image' style='width:100px;height:100px;'></td><td>" . $row["name"] . "</td><td>" . $row["address"] . "</td><td>" . $row["phoneNum"] . "</td><td>" . $row["blood_group"] . "</td><td>" . $row["keywords"] . "</td></tr>";
                }
            } else {
                echo "<tr><td colspan='7'>0 results</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </div>

    <script>
        document.getElementById("search_query").addEventListener("input", function() {
            var input = this.value.toLowerCase();
            var table = document.getElementById("search-table");
            var rows = table.getElementsByTagName("tr");
            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName("td");
                var found = false;
                for (var j = 1; j < cells.length; j++) {
                    var cellText = cells[j].textContent || cells[j].innerText;
                    if (cellText.toLowerCase().indexOf(input) > -1) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        });
    </script>
</body>

</html>