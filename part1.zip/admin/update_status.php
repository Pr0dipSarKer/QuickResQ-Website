<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"]) && isset($_POST["solved"])) {
    // Update the solved status in the database
    $id = $_POST["id"];
    $solved = $_POST["solved"];

    $conn = mysqli_connect("localhost", "root", "", "quickresq");
    $sql = "UPDATE emergency_requests SET solved = $solved WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Status updated successfully";
    } else {
        echo "Error updating status: " . $conn->error;
    }

    $conn->close();
}
?>
