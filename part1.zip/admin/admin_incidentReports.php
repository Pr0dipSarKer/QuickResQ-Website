<?php
session_start();
include("connection.php");

// Establish database connection
$conn = new mysqli('localhost', 'root', '', 'quickresq');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submissions
if (isset($_POST["submit1"])) {
    // Insert new incident report
    $user_name = $conn->real_escape_string($_POST['user_name']);
    $incident_type = $conn->real_escape_string($_POST['incident_type']);
    $incident_details = $conn->real_escape_string($_POST['incident_details']);
    $location = $conn->real_escape_string($_POST['location']);

    $sql = "INSERT INTO incident_reports (user_name, incident_type, incident_details, location, date)
            VALUES ('$user_name', '$incident_type', '$incident_details', '$location', NOW())";
    if ($conn->query($sql) === TRUE) {
        $report_id = $conn->insert_id;
        foreach ($_FILES['incident_pictures']['tmp_name'] as $key => $tmp_name) {
            $file_content = file_get_contents($tmp_name);
            $encoded_file = $conn->real_escape_string($file_content);
            $photo_sql = "INSERT INTO incident_photos (report_id, photo_data) VALUES ('$report_id', '$encoded_file')";
            $conn->query($photo_sql);
        }
        echo "<script>alert('Successfully INSERTED')</script>";
        header('Location: admin_incidentReports.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

if (isset($_POST["submit2"])) {
    // Delete incident report
    $report_id = $conn->real_escape_string($_POST['report_id']);

    $delete_photo_sql = "DELETE FROM incident_photos WHERE report_id='$report_id'";
    if ($conn->query($delete_photo_sql) === FALSE) {
        echo "Error deleting old photos: " . $conn->error;
        exit();
    }

    $sql = "DELETE FROM incident_reports WHERE report_id='$report_id'";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Successfully DELETED')</script>";
        header('Location: admin_incidentReports.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


// Fetching and displaying incident reports
$sql = "SELECT * FROM incident_reports ORDER BY date DESC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - ADMIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="Admin_CSS/admin_incidentReports.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="..." crossorigin="anonymous" />
    <style>
        .delete-btn,
        .update-btn {
            cursor: pointer;
            margin-left: 10px;
        }
    </style>
</head>

<body>
    <header>
        <div class="topnav">
            <h5 style="align-items: center;">Emergency Support System</h5>
        </div>

        <div class="logo">
            <a href="admin_home.php">
                <img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo">
            </a>
        </div>
        <div id="buttonStyle">
            <ul>
                <li><a href="../admin/admin_hospital.php">Hospital</a></li>
                <li><a href="admin_ambulance.php">Ambulance</a></li>
                <li><a href="../admin/admin_findblood.php">Find Blood</a></li>
                <li><a href="../admin/admin_fireservice.php">Fire Service</a></li>
                <li><a href="../admin/admin_policestation.php">Police</a></li>
                <li><a href="admin_volunteer.php">Volunteer</a></li>
                <li><a href="admin_fastaid.php">Fastaid</a></li>
                <li><a href="admin_erequest.php">E-Request</a></li>
                <li><a href="admin_incidentReports.php">Incidents</a></li>
                <a href="admin_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </ul>
        </div>
    </header>

    <div id="box1">
        <form method="post" enctype="multipart/form-data">
            <div style="font-size: 20px; font-weight:bold; margin-bottom: 10px; color: black; text-align:center;">Incident Reports</div>
            <div class="form-group">
                <label for="user_name">User Name</label><br>
                <input id="user_name" type="text" name="user_name" required><br>
            </div>
            <div class="form-group">
                <label for="incident_type">Incident Type</label><br>
                <input id="incident_type" type="text" name="incident_type"><br>
            </div>
            <div class="form-group">
                <label for="incident_details">Incident Details</label><br>
                <textarea id="incident_details" name="incident_details"></textarea><br>
            </div>
            <div class="form-group">
                <label for="location">Location</label><br>
                <input id="location" type="text" name="location"><br>
            </div>
            <div class="form-group">
                <label for="incident_pictures">Upload Pictures</label><br>
                <input id="incident_pictures" type="file" name="incident_pictures[]" multiple><br>
            </div>
            <div class="btn-group">
                <input type="submit" value="INSERT" name="submit1">
            </div>
        </form>
    </div>

    <div id="search-container">
        <form>
            <input type="text" id="search_query" name="search_query" placeholder="Search by user name, incident type, location">
        </form>
    </div>

    <div>
        <table border="1" cellspacing="1" cellpadding="10" id="search-table">
            <tr>
                <th>ID</th>
                <th>User Name</th>
                <th>Incident Type</th>
                <th>Incident Details</th>
                <th>Location</th>
                <th>Date</th>
                <th>Pictures</th>
                <th>Action</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["report_id"] . "</td>";
                    echo "<td>" . htmlspecialchars($row["user_name"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["incident_type"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["incident_details"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["location"]) . "</td>";
                    echo "<td>" . date('Y-m-d h:i A', strtotime($row["date"])) . "</td>";
                    echo "<td class='report-images'>";
                    $report_id = $row["report_id"];
                    $photo_sql = "SELECT photo_data FROM incident_photos WHERE report_id = $report_id";
                    $photo_result = $conn->query($photo_sql);
                    if ($photo_result->num_rows > 0) {
                        while ($photo_row = $photo_result->fetch_assoc()) {
                            echo "<img src='data:image/jpeg;base64," . base64_encode($photo_row["photo_data"]) . "' alt='Incident Picture' style='width: 100px; height: auto;'>";
                        }
                    } else {
                        echo "No pictures available";
                    }
                    echo "</td>";
                    echo "<td>";
                    echo "<form method='post' style='display: inline-block;'>";
                    echo "<input type='hidden' name='report_id' value='" . $row["report_id"] . "'>";
                    echo "<input type='submit' value='DELETE' name='submit2' class='delete-btn'>";
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8'>0 results</td></tr>";
            }
            $conn->close(); // Close connection after all database operations
            ?>
        </table>
    </div>

    <script>
        document.getElementById("search_query").addEventListener("input", function() {
            var input = this.value.toLowerCase();
            var table = document.getElementById("search-table");
            var rows = table.getElementsByTagName("tr");
            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName("td");
                var found = false;
                for (var j = 1; j < cells.length - 1; j++) { // Exclude last column (action buttons)
                    var cellText = cells[j].textContent || cells[j].innerText;
                    if (cellText.toLowerCase().indexOf(input) > -1) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        });
    </script>
</body>

</html>
