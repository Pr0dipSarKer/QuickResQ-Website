<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - ADMIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="Admin_CSS/admin_findblood.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="..." crossorigin="anonymous" />
</head>

<body>
    <header>
        <div class="topnav">
            <h5 style="align-items: center;">Emergency Support System</h5>
        </div>

        <div class="logo">
            <a href="admin_home.php">
                <img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo">
            </a>
        </div>
        <div id="buttonStyle">
            <ul>
                <li><a href="admin_hospital.php">Hospital</a></li>
                <li><a href="admin_ambulance.php">Ambulance</a></li>
                <li><a href="admin_findblood.php">Find Blood</a></li>
                <li><a href="admin_fireservice.php">Fire Service</a></li>
                <li><a href="admin_policestation.php">Police</a></li>
                <li><a href="admin_volunteer.php">Volunteer</a></li>
                <li><a href="admin_fastaid.php">Fastaid</a></li>
                <li><a href="admin_erequest.php">E-Request</a></li>
                <li><a href="admin_incidentReports.php">Incidents</a></li>
                <a href="admin_logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </ul>
        </div>
    </header>

    <?php
    session_start();
    include("connection.php");
    ?>
    <?php
    $conn = mysqli_connect('localhost', 'root', '', 'quickresq');

    if (isset($_POST["submit1"])) {
        $sql = "INSERT INTO bloodbankdatabase(name , blood_group , address , phoneNum , website , keyword)
    VALUES('$_POST[name]', '$_POST[blood_group]', '$_POST[address]', '$_POST[phoneNum]', '$_POST[website]',  '$_POST[keyword]')";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully INSERT')</script>";
            header('Location: admin_findblood.php');
            exit();
        }
    }

    if (isset($_POST["submit2"])) {
        $sql = "DELETE FROM bloodbankdatabase WHERE name='$_POST[name]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully DELETE')</script>";
            header('Location: admin_findblood.php');
            exit();
        }
    }

    if (isset($_POST["submit3"])) {
        $sql = "UPDATE bloodbankdatabase SET  name='$_POST[name]', blood_group='$_POST[blood_group]', address='$_POST[address]', phoneNum='$_POST[phoneNum]', website='$_POST[website]',  keyword='$_POST[keyword]' WHERE name= '$_POST[name]'";
        if ($conn->query($sql) === true) {
            echo "<script>alert('Successfully UPDATE')</script>";
            header('Location: admin_findblood.php');
            exit();
        }
    }
    ?>


    <div id="box1">
        <form method="post">
            <div style="font-size: 20px; font-weight:bold; margin-bottom: 10px; color: black; text-align:center;">Find Blood</div>
            <div class="form-group">
                <label for="name">Name</label><br>
                <input id="name" type="text" name="name" required><br>
            </div>
            <div class="form-group">
                <label for="blood_group">Blood Group</label><br>
                <select id="blood_group" type="text" name="blood_group" required>
                    <option value="All">All</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                </select><br>
            </div>
            <div class="form-group">
                <label for="address">Address</label> <br>
                <input id="address" type="text" name="address"><br>
            </div>
            <div class="form-group">
                <label for="phoneNum">Phone Number</label><br>
                <input id="phoneNum" type="text" name="phoneNum"><br>
            </div>
            <div class="form-group">
                <label for="website">Website</label><br>
                <input id="website" type="text" name="website"><br>
            </div>
            <div class="form-group">
                <label for="keyword">Keywords</label><br>
                <input id="keyword" type="text" name="keyword"><br>
            </div>

            <div class="btn-group">
                <input type="submit" value="INSERT" name="submit1">
                <input type="submit" value="DELETE" name="submit2">
                <input type="submit" value="UPDATE" name="submit3">
            </div>
        </form>
    </div>


    <div id="search-container">
        <form>
            <input type="text" id="search_query" name="search_query" placeholder="Search by name, blood group, address, phone number, website, or keywords">
        </form>
    </div>

    <div>
        <table border="1" cellspacing="1" cellpadding="10" id="search-table">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Blood Group</th>
                <th>Address</th>
                <th>Phone Number</th>
                <th>Website</th>
                <th>Keywords</th>
            </tr>
            <?php
            $conn = mysqli_connect("localhost", "root", "", "quickresq");

            $sql = "SELECT id, name , blood_group , address , phoneNum , website , keyword FROM bloodbankdatabase";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["id"] . "</td><td>" . $row["name"] . "</td><td>" . $row["blood_group"] . "</td><td>" . $row["address"] . "</td><td>" . $row["phoneNum"] . "</td><td>" . $row["website"] . "</td><td>" . $row["keyword"] .  "</td></tr>";
                }
            } else {
                echo "<tr><td colspan='7'>0 results</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </div>

    <script>
        document.getElementById("search_query").addEventListener("input", function() {
            var input = this.value.toLowerCase();
            var table = document.getElementById("search-table");
            var rows = table.getElementsByTagName("tr");
            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName("td");
                var found = false;
                for (var j = 1; j < cells.length; j++) {
                    var cellText = cells[j].textContent || cells[j].innerText;
                    if (cellText.toLowerCase().indexOf(input) > -1) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        });
    </script>
</body>

</html>