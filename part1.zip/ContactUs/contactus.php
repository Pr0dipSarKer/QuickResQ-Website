<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>


<?php
include_once('connection.php');

if (isset($_POST['contactus'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    // Validation
    if (empty($name) || empty($email) || empty($phone) || empty($message)) {
        echo "<script>alert('All fields are required');</script>";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format');</script>";
    } else {
        // No need to hash phone and message
        $sql = "INSERT INTO `contactus`(`name`, `email`, `phone`, `message`) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $phone, $message);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('New User Register Success');</script>";
            header('Location: contactus.php');
            exit();
        } else {
            echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        }
        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickResQ - Contact Form</title>
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>

</head>

<body>
    <!-- Add the top navigation here -->

    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>


    <header>

        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="../EmergencyRequest/emergency_request_form.php">Need Help</a></li>
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>


    <div class="container">
        <div class="form">
            <div class="contact-info">
                <h3 class="title">Let's get in touch</h3>
                <p class="text">
                    For urgent assistance or any suggestions, contact us. Our team will respond promptly to your emergency. </p>

                <div class="info">
                    <div class="information">
                        <img src="img/location.png" class="icon" alt="" />
                        <p>B/7, Gulshan 2, Dhaka 1212</p>
                    </div>
                    <div class="information">
                        <img src="img/email.png" class="icon" alt="" />
                        <p>quickresq@info.org.bd</p>
                    </div>
                    <div class="information">
                        <img src="img/phone.png" class="icon" alt="" />
                        <p>123-456-789</p>
                    </div>
                </div>

                <div class="social-media">
                    <p>Connect with us :</p>
                    <div class="social-icons">
                        <a href="https://www.facebook.com/joy.pal.hazard">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://twitter.com/JoyPal_hazard">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="https://www.instagram.com/joy__hazard/">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="https://www.linkedin.com/in/joy-pal-hazard/">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
            </div>

            <div class="contact-form">

                <form action="contactus.php" method="post" autocomplete="off">
                    <h3 class="title">Contact us</h3>
                    <div class="input-container">
                        <input type="text" name="name" class="input" required />
                        <label for="">Username</label>
                        <span>Username</span>
                    </div>
                    <div class="input-container">
                        <input type="email" name="email" class="input" required />
                        <label for="">Email</label>
                        <span>Email</span>
                    </div>
                    <div class="input-container">
                        <input type="tel" name="phone" class="input" required />
                        <label for="">Phone</label>
                        <span>Phone</span>
                    </div>
                    <div class="input-container textarea">
                        <textarea name="message" class="input" required></textarea>
                        <label for="">Message</label>
                        <span>Message</span>
                    </div>
                    <input type="submit" value="Send" class="btn" name="contactus" />
                </form>
            </div>
        </div>
    </div>

    <script src="app.js"></script>


    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email:quickresq@info.org.bd</p>
                <p>Phone:+123 456 789</p>
                <p>Address:B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>

    </footer>
</body>

</html>