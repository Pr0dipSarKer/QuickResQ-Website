<?php
session_start();
include_once('connection.php');

$_SESSION['name'];
$_SESSION['username'];

$conn = mysqli_connect('localhost', 'root', '', 'quickresq');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $incident_details = $_POST['incident_details'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    $sql = "INSERT INTO emergency_requests (name, phone, address, incident_details, latitude, longitude)
            VALUES ('$name', '$phone', '$address', '$incident_details', '$latitude', '$longitude')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>window.address.href = 'emergency_request_form.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickResQ - Emergency Request Form</title>
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="view_request.css">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
</head>

<body>
    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>

    <header>
        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="emergency_request_form.php">Need Help</a>
                    <ul>
                        <li><a href="view_requests.php">View Request</a></li>
                        <li><a href="map.php">See Helper</a></li>
                        <li><a href="../FavoriteContacts/favoriteContact.php">Contacts</a></li>
                    </ul>
                </li>
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>


    <?php


    $sql = "SELECT * FROM emergency_requests";
    $result = $conn->query($sql);
    ?>

    <h1>Emergency Requests</h1>
    <div id="requests">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='request-container'>";
                // Add badge based on solved status
                $badge = ($row['solved']) ? "<span class='badge solved'>Solved</span>" : "<span class='badge unsolved'>Unsolved</span>";
                echo $badge;
                echo "<div class='request-details'>";
                echo "<p>Name: " . $row['name'] . "</p>";
                echo "<p>Phone: " . $row['phone'] . "</p>";
                echo "<p>address: <span id='address_" . $row['id'] . "'>" . $row['address'] . "</span></p>";
                echo "<p>Incident Details: " . $row['incident_details'] . "</p>";
                echo "</div>";
                echo "<div class='request-map'>";
                echo "<div id='map_" . $row['id'] . "' class='map'></div>";
                echo "</div>";
                echo "</div>";
                echo "<script>
                        var lat = " . $row['latitude'] . ";
                        var lng = " . $row['longitude'] . ";
                        var map = L.map('map_" . $row['id'] . "').setView([lat, lng], 15);
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: '&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> contributors'
                        }).addTo(map);
                        var marker = L.marker([lat, lng]).addTo(map);

                        // Fetch address using OpenCage API
                        fetch('https://api.opencagedata.com/geocode/v1/json?q=' + lat + '+' + lng + '&countrycode=bd&key=7bc38d22cc91438eb42f41ed38e0197f')
                            .then(response => response.json())
                            .then(data => {
                                if (data.results.length > 0) {
                                    document.getElementById('address_" . $row['id'] . "').innerText = data.results[0].formatted;
                                } else {
                                    document.getElementById('address_" . $row['id'] . "').innerText = 'address not found';
                                }
                            })
                            .catch(error => {
                                document.getElementById('address_" . $row['id'] . "').innerText = 'Error: ' + error;
                            });
                      </script>";
            }
        } else {
            echo "<p>No emergency requests found.</p>";
        }
        $conn->close();
        ?>
    </div>

























    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email: quickresq@info.org.bd</p>
                <p>Phone: +123 456 789</p>
                <p>Address: B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>
    </footer>


</body>

</html>