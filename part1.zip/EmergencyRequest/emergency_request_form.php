<?php
session_start();
include_once('connection.php');

$_SESSION['name'];
$_SESSION['username'];

$conn = mysqli_connect('localhost', 'root', '', 'quickresq');

// Txtlocal credentials
$username = "quickresq.ess.org.bd@gmail.com";
$hash = "20edcbdd443118e188d49f9c78cc77ecec8758723cda2af69e493fd216e31028";
$test = "0";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $incident_details = mysqli_real_escape_string($conn, $_POST['incident_details']);
    $latitude = mysqli_real_escape_string($conn, $_POST['latitude']);
    $longitude = mysqli_real_escape_string($conn, $_POST['longitude']);

    $sql = "INSERT INTO emergency_requests (name, phone, address, category, incident_details, latitude, longitude)
            VALUES ('$name', '$phone', '$address', '$category', '$incident_details', '$latitude', '$longitude')";

    if ($conn->query($sql) === TRUE) {
        sendNotificationViaTxtlocal($name, $phone, $address, $category, $incident_details, $latitude, $longitude, $conn);
        echo "<script>window.location.href = 'emergency_request_form.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}

function sendNotificationViaTxtlocal($name, $phone, $address, $category, $incident_details, $latitude, $longitude, $conn)
{
    global $username, $hash, $test;

    // Txtlocal settings
    $sender = "QuickResq";

    // Fetch recipient numbers from database based on location and category
    $recipientNumbers = [];

    // Define categories and their corresponding tables
    $categories = [
        'ambulance' => 'ambulancedatabase',
        'hospital' => 'hospitaldatabase',
        'fire service' => 'fireservicesdatabase',
        'police' => 'policestationdatabase',
        'blood' => 'bloodbankdatabase',
        'volunteer' => 'volunteer'
    ];

    // Radius in kilometers for nearby search
    $radius = 10;

    if (isset($categories[$category])) {
        $table = $categories[$category];

        // Query to fetch recipient numbers within the radius
        $sql = "SELECT phoneNum,
                ( 6371 * acos( cos( radians($latitude) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians($longitude) ) + sin( radians($latitude) ) * sin( radians( latitude ) ) ) ) AS distance
                FROM $table
                HAVING distance < $radius
                ORDER BY distance";

        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            $recipientNumbers[] = $row['phoneNum'];
        }
    }

    // Check if we have any recipients
    if (empty($recipientNumbers)) {
        echo "No nearby emergency service providers found for the specified category.";
        return;
    }

    // Remove duplicates and format for Txtlocal API
    $recipientNumbers = array_unique($recipientNumbers);
    $numbers = implode(",", $recipientNumbers);

    $message = "Emergency Help Needed:\n\n" .
        "Name: $name\n" .
        "Phone: $phone\n" .
        "Address: $address\n" .
        "Category: $category\n" .
        "Incident Details: $incident_details\n" .
        "Latitude: $latitude\n" .
        "Longitude: $longitude";

    $message = urlencode($message);
    $data = "username=$username&hash=$hash&message=$message&sender=$sender&numbers=$numbers&test=$test";

    $ch = curl_init('https://api.txtlocal.com/send/?');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);

    // Check result from Txtlocal API
    if (strpos($result, "success") !== false) {
        echo "SMS via Txtlocal sent successfully!";
    } else {
        echo "SMS via Txtlocal failed: " . $result;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickResQ - Emergency Request Form</title>
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="emergency_request.css">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>

    <header>
        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="#">Need Help</a>
                    <ul>
                        <li><a href="view_requests.php">View Request</a></li>
                        <li><a href="map.php">See Helper</a></li>
                        <li><a href="../FavoriteContacts/favoriteContact.php">Contacts</a></li>
                    </ul>
                </li>
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <div id="form-container">
        <form id="emergency-form" method="post" action="emergency_request_form.php">
            <div style="font-size: 20px; font-weight:bold; margin-bottom: 10px; color: black; text-align:center;">Emergency Request Form</div>
            <div class="form-group">
                <label for="name">Name<span class="required">*</span></label><br>
                <input id="name" type="text" name="name" required><br>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number<span class="required">*</span></label><br>
                <input id="phone" type="text" name="phone" required><br>
            </div>
            <div class="form-group">
                <label for="address">Location<span class="required">*</span></label><br>
                <input id="address" type="text" name="address" readonly required><br>
                <button type="button" onclick="getLocation()">Detect Location</button><br>
            </div>
            <div class="form-group">
                <label for="category">Type of Emergency Support Need<span class="required">*</span></label><br>
                <select id="category" name="category" required>
                    <option value="ambulance">Ambulance</option>
                    <option value="police">Police Station</option>
                    <option value="hospital">Hospital</option>
                    <option value="fire">Fire Service</option>
                    <option value="blood">Blood</option>
                    <option value="volunteer">Volunteer</option>
                </select><br>
            </div>
            <div class="form-group">
                <label for="incident_details">Incident Details<span class="required">*</span></label><br>
                <textarea id="incident_details" name="incident_details" required></textarea><br>
            </div>
            <div class="form-group">
                <input type="hidden" id="latitude" name="latitude" required>
                <input type="hidden" id="longitude" name="longitude" required>
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>


    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email: quickresq@info.org.bd</p>
                <p>Phone: +123 456 789</p>
                <p>Address: B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>
    </footer>

    <script>
        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition, showError);
            } else {
                alert("Geolocation is not supported by this browser.");
            }
        }

        function showPosition(position) {
            var lat = position.coords.latitude; // Get the latitude from the geolocation API
            var lng = position.coords.longitude; // Get the longitude from the geolocation API
            document.getElementById("latitude").value = lat;
            document.getElementById("longitude").value = lng;

            var apiKey = '7bc38d22cc91438eb42f41ed38e0197f'; // Replace with your actual OpenCage API key
            var url = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lng}&key=${apiKey}`;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.results.length > 0) {
                        document.getElementById("address").value = data.results[0].formatted; // Set the value of the 'address' field
                    } else {
                        alert('No results found');
                    }
                })
                .catch(error => {
                    alert('Error: ' + error);
                });
        }

        function showError(error) {
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    alert("User denied the request for Geolocation.");
                    break;
                case error.POSITION_UNAVAILABLE:
                    alert("Location information is unavailable.");
                    break;
                case error.TIMEOUT:
                    alert("The request to get user location timed out.");
                    break;
                case error.UNKNOWN_ERROR:
                    alert("An unknown error occurred.");
                    break;
            }
        }
    </script>
</body>

</html>