<?php
session_start();
include_once('connection.php');

$conn = mysqli_connect('localhost', 'root', '', 'quickresq');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve service providers with their phone numbers
$sql = "SELECT service_token, phoneNum, latitude, longitude FROM service_tokens";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Initialize array to store service provider data
    $providers = array();

    // Fetch data and store in array
    while ($row = $result->fetch_assoc()) {
        $provider = array(
            'serviceToken' => $row['service_token'],
            'phoneNum' => $row['phoneNum'],
            'lat' => $row['latitude'],
            'lng' => $row['longitude']
        );
        array_push($providers, $provider);
    }

    // Convert array to JSON and echo (this will be used by JavaScript on the front-end)
    $providers_json = json_encode($providers);
} else {
    $providers_json = "[]"; // Return an empty array if no providers found
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickResQ - Map</title>
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="map.css">
    <script type="text/javascript" src="https://www.bing.com/api/maps/mapcontrol?key=AhAS9oCnpIzheGbQNPrr2Aycbo-GIJQXjiGqwEnete4bsbRpDQlYi0cFdiyZsIOM"></script>
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>
    <script>
        var map;
        var providersData = <?php echo $providers_json; ?>; // PHP array to JavaScript

        function initMap() {
            map = new Microsoft.Maps.Map('#map', {
                center: new Microsoft.Maps.Location(23.8103, 90.4125),
                zoom: 10
            });

            getCurrentLocation();
        }

        function getCurrentLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        var userLocation = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        console.log('User location:', userLocation);
                        map.setView({
                            center: new Microsoft.Maps.Location(userLocation.lat, userLocation.lng),
                            zoom: 14
                        });

                        displayProvidersOnMap(providersData, userLocation);
                    },
                    function(error) {
                        console.error('Error getting user location:', error);
                        alert('Error getting your location. Please allow location access.');
                    }
                );
            } else {
                alert('Geolocation is not supported by this browser.');
            }
        }

        function displayProvidersOnMap(providers, userLocation) {
            providers.forEach(provider => {
                var location = new Microsoft.Maps.Location(provider.lat, provider.lng);
                var distance = haversineDistance(userLocation.lat, userLocation.lng, provider.lat, provider.lng);

                if (distance <= 5) { // Adjust this distance as per your requirement
                    var pin = new Microsoft.Maps.Pushpin(location, {
                        title: provider.serviceToken,
                        subTitle: 'Phone: ' + provider.phoneNum
                    });
                    map.entities.push(pin);
                }
            });
        }

        // Function to calculate distance between two points in kilometers using Haversine formula
        function haversineDistance(lat1, lon1, lat2, lon2) {
            var R = 6371; // Radius of the Earth in kilometers

            var dLat = deg2rad(lat2 - lat1);
            var dLon = deg2rad(lon2 - lon1);

            var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);

            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

            var distance = R * c; // Distance in kilometers

            return distance;
        }

        function deg2rad(deg) {
            return deg * (Math.PI / 180);
        }
    </script>
</head>

<body onload="initMap()">
    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>

    <header>
        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="emergency_request_form.php">Need Help</a>
                    <ul>
                        <li><a href="view_requests.php">View Request</a></li>
                        <li><a href="map.php">See Helper</a></li>
                        <li><a href="../FavoriteContacts/favoriteContact.php">Contacts</a></li>
                    </ul>
                </li>
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <div class="form">
        <div class="location-form">
            <label for="address">Your Current Location<span class="required">*</span></label><br>
            <button style="float:center" type="button" onclick="getCurrentLocation()">Detect Location</button><br>
        </div>
    </div>

    <h1 style="margin-top: 10px; margin-bottom:50px ;font-size:30px; font-weight: bold ; text-align:center;">Service Provider Near You</h1>
    <div id="map" style="width: 100%; height: 500px;"></div>

    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email: quickresq@info.org.bd</p>
                <p>Phone: +123 456 789</p>
                <p>Address: B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>
    </footer>
</body>

</html>
