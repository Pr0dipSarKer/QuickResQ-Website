<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - Developer Team</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="Image/QuickResQ_icon.png" type="image/x-icon" />
    <link href="aboutus.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>

</head>


<body>
    <!-- Add the top navigation here -->

    <div class="marquee">
        <span>Welcome
            <?= $_SESSION['name']; ?> to QuickResQ
        </span>
    </div>


    <header>

        <div class="logo">
            <a href="index.php"><img src="Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="Hospital/hospital.php">Hospital</a></li>
                        <li><a href="Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="Blood/blood.php">Blood</a></li>
                        <li><a href="PoliceStation/police.php">Police Station</a></li>
                        <li><a href="FireService/fireService.php">Fire Services</a></li>
                        <li><a href="Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="EmergencyRequest/emergency_request_form.php">Need Help</a></li>
                <li><a href="IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="Login_Register/logout.php"><img src="Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <div class="about-section">
        <h1>About Us</h1>
        <p>QuickResQ: Empowering Communities, Saving Lives. <br>Driven by compassion, expertise, and dedication, our team of three strives to make a difference in every life we touch.</p>
    </div>

    <div class="mission-section">
        <h2>Our Mission</h2>
        <p>At QuickResQ, our mission is to provide timely and reliable emergency assistance to communities in need, leveraging technology and human compassion to save lives and support those in distress.</p>
    </div>


    <h2 style="position:relative; top:100px; text-align:center;">Our Team</h2>
    <div class="row">
        <div class="column">
            <div class="card">
                <img src="Image/Joy.png" alt="Joy" style="width:100%">
                <div class="containerC">
                    <h2 style="text-align: center; padding-top: 5px;">Joy Pal</h2>
                    <p class="title">CEO & Founder (Chief Developer)</p>
                    <!-- Social media icons -->
                    <p>
                        <a href="https://github.com/Joy-hazard" class="fa fa-github"></a>
                        <a href="https://www.linkedin.com/in/joy-pal-hazard/" class="fa fa-linkedin"></a>
                        <a href="https://www.facebook.com/joy.pal.hazard" class="fa fa-facebook"></a>
                        <a href="mailto:joypal.hazard@gmail.com" class="fa fa-envelope"></a> <!-- Updated icon class -->
                    </p>
                </div>
            </div>
        </div>
        <div class="column">
            <div class="card">
                <img src="Image/Aminul.png" alt="Aminul" style="width:100%">
                <div class="containerC">
                    <h2 style="text-align: center; padding-top: 5px;">Aminul Islam</h2>
                    <p class="title">Supporting Developer</p>
                    <!-- Social media icons -->
                    <p>
                        <a href="#" class="fa fa-github"></a>
                        <a href="#" class="fa fa-linkedin"></a>
                        <a href="#" class="fa fa-facebook"></a>
                        <a href="#" class="fa fa-envelope"></a> <!-- Updated icon class -->
                    </p>
                </div>
            </div>
        </div>
        <div class="column">
            <div class="card">
                <img src="Image/Prodip.jpg" alt="Prodip" style="width:100%">
                <div class="containerC">
                    <h2 style="text-align: center; padding-top: 5px;">Prodip Sarker</h2>
                    <p class="title">Supporting Developer</p>
                    <!-- Social media icons -->
                    <p>
                        <a href="#" class="fa fa-github"></a>
                        <a href="#" class="fa fa-linkedin"></a>
                        <a href="#" class="fa fa-facebook"></a>
                        <a href="#" class="fa fa-envelope"></a> <!-- Updated icon class -->
                    </p>
                </div>
            </div>
        </div>
    </div>


    <div class="message-cards-container">
        <div class="message-card">
            <p class="message-text">"At QuickResQ, we extend our helping hand to those in need, providing timely assistance and support in emergency situations. With compassion as our guiding principle, we strive to empower communities and save lives. Together, let's make a difference and create a safer, more resilient world."</p>
            <p class="author">- Joy Pal</p>
        </div>
        <div class="message-card">
            <p class="message-text">"Hello everyone! Aminul Islam here, one of the supporting developers behind QuickResQ. I am honored to be part of a team dedicated to making a positive impact in our community. Together, we're leveraging technology to provide emergency support and save lives. Let's continue working hand in hand to make a difference where it's needed most. Thank you for trusting us!"</p>
            <p class="author">- Aminul Islam</p>
        </div>
        <div class="message-card">
            <p class="message-text">"It's truly inspiring to be part of a team dedicated to serving our community in times of need. With our collective efforts, we're striving to make emergency assistance more accessible and efficient for everyone. Let's continue our journey together, making a real difference one step at a time. Thank you for your support!"</p>
            <p class="author">- Prodip Sarker</p>
        </div>
    </div>



    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email:quickresq@info.org.bd</p>
                <p>Phone:+123 456 789</p>
                <p>Address:B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="mobileapp.php">Mobile App</a></li>
                    <li><a href="ContactUs/contactus.php">Contact Us</a></li>
                    <li><a href="User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="footer_assets/copyright_policy.html">Copyright Policy</a> ||
                <a href="footer_assets/terms_conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>

    </footer>
</body>

</html>