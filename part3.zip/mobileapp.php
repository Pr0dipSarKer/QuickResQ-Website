<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>

<!doctype html>
<html lang="en">

<head>
    <title>QuickResQ - Download app</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="Image/QuickResQ_icon.png" type="image/x-icon" />
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>

</head>


<body>
    <!-- Add the top navigation here -->

    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>


    <header>

        <div class="logo">
            <a href="index.php"><img src="Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="Hospital/hospital.php">Hospital</a></li>
                        <li><a href="Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="Blood/blood.php">Blood</a></li>
                        <li><a href="PoliceStation/police.php">Police Station</a></li>
                        <li><a href="FireService/fireService.php">Fire Services</a></li>
                        <li><a href="Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="EmergencyRequest/emergency_request_form.php">Need Help</a></li>
                <li><a href="IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="Login_Register/logout.php"><img src="Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <div class="text">
        <p>
            Download QuickResQ App !
        </p>

    </div>

    <div class="main-content">
        <div class="app-info">
            <div class="mobile-picture">
                <!-- Mobile picture here -->
                <img src="Image/whentouse/phone.png" alt="Mobile Picture">
            </div>
            <div class="qr-code">
                <!-- QR code here -->
                <img src="Image/whentouse/R.png" alt="QR Code">
            </div>
        </div>

        <div class="app-links">
            <!-- Google PlayStore link -->
            <a href="https://play.google.com/store/apps/details?id=com.example.app">
                <img src="Image/whentouse/googleplay.jpg" alt="Google Play Store">
            </a>
            <!-- Apple App Store link -->
            <a href="https://apps.apple.com/us/app/your-app/id1234567890">
                <img src="Image/whentouse/OIP.jpg" alt="Apple App Store">
            </a>
        </div>

        <!-- Screenshots and App Demo Section -->
        <div class="screenshots-demo">
            <h2>Screenshots and App Demo</h2>
            <div class="app-demo">
                <div class="mobile-screenshots">
                    <img src="Image/Mobile_ss/1.jpg" alt="Screenshot 1">
                    <img src="Image/Mobile_ss/2.jpg" alt="Screenshot 2">
                    <img src="Image/Mobile_ss/3.jpg" alt="Screenshot 3">
                    <img src="Image/Mobile_ss/4.jpg" alt="Screenshot 4">
                    <img src="Image/Mobile_ss/6.jpg" alt="Screenshot 6">
                </div>
                <div class="app-video">
                    <!-- Add your app demo video here -->
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/your-app-demo-video" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>

        <!-- Frequently Asked Questions (FAQs) Section -->
        <div class="faq">
            <h2>Frequent Queries </h2>
            <div class="faq-item">
                <h3>How do I download the QuickResQ app?</h3>
                <p>You can download the app from the Google Play Store or Apple App Store using the links provided above.</p>
            </div>
            <div class="faq-item">
                <h3>Is the QuickResQ app free?</h3>
                <p>Yes, the app is completely free to download and use.</p>
            </div>
            <div class="faq-item">
                <h3>How do I find emergency services?</h3>
                <p>The app provides quick access to various emergency services like hospitals, police, and fire stations.</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email:quickresq@info.org.bd</p>
                <p>Phone:+123 456 789</p>
                <p>Address:B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="mobileapp.php">Mobile App</a></li>
                    <li><a href="ContactUs/contactus.php">Contact Us</a></li>
                    <li><a href="User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>

    </footer>
</body>

</html>





<style>
    body {
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
        overflow-x: hidden;
        /* Prevent horizontal scrolling */
    }

    .marquee {
        display: flex;
        overflow: hidden;
        width: 200px;
        /* Set the desired width */
        padding: 2px 4px;
        color: #c62828;
    }

    .marquee>* {
        white-space: nowrap;
        /* Prevent content from wrapping */
    }

    @keyframes marquee {
        from {
            transform: translateX(100%);
            /* Start from the right end */
        }

        to {
            transform: translateX(-100%);
            /* End at the left end */
        }
    }

    .marquee>* {
        animation: marquee 7s linear infinite;
    }

    .logo {
        flex: 0 0 auto;
        position: relative;
        top: 10px;
        left: 40px;
    }

    .logo img {
        top: 10px;
        width: 190px;
        height: 80px;
        border-radius: 5px;
    }

    .flag {
        flex: 0 0 auto;
        max-height: 100px;
        /* Maintain aspect ratio */
        max-width: 180px;
        margin-right: 200px;
        /* Adjust margin as needed */
        float: right;
    }

    #buttonStyle {
        position: relative;
        top: 30px;
        z-index: 100;
        background-color: #ccc4c4;
        height: 50px;
        width: 100%;
        display: flex;
        justify-content: flex-start;
        /* Align items to the left */
        align-items: center;
        /* Vertically center the items */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        /* Apply box-shadow to the navbar */
    }

    #buttonStyle ul {
        list-style: none;
        margin: 0;
        display: flex;
        /* Align items in a row */
    }

    #buttonStyle ul li {
        border-radius: 5px;
        border: 1px solid transparent;
        margin: 0 10px;
        /* Adjust margin between buttons */
        height: 40px;
        /* Set the height of the button */
        line-height: 40px;
        /* Vertically center the text */
        font-family: Arial;
        position: relative;
    }

    #buttonStyle ul li a {
        font-size: 16px;
        font-weight: bold;
        font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        text-decoration: none;
        color: rgb(40, 35, 63);
        display: block;
        width: 120px;
        /* Set the width of the button */
        text-align: center;
        /* Center the text horizontally */
    }

    #buttonStyle ul li a:hover {
        border-radius: 5px;
        box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
        /* Move box-shadow above the navbar */
        border: 1px solid #ccc;
        /* Add a border to the button on hover */
    }

    #buttonStyle ul li a:active {
        position: relative;
    }

    #buttonStyle ul ul {
        margin: 0px;
        padding: 2px;
        position: absolute;
        display: none;
        background-color: #ccc4c4;
    }

    #buttonStyle ul li:hover>ul {
        display: block;
    }

    #buttonStyle ul ul li {
        width: 120px;
        margin: 4px;
    }

    /* Position the logout button to the right */
    #buttonStyle ul li#logout {
        margin-left: 280px;
        /* Push logout button to the right */
    }


    /* Additional styling for the logout image */
    #buttonStyle ul li#logout img.logout {
        width: 30px;
        /* Set the width of the image */
        height: 30px;
        /* Set the height of the image */
        margin: 4px;
    }





    /* CSS styles for the mobile app page */


    .text {
        margin-top: 100px;
        margin-bottom: 30px;
        color: rgb(49, 16, 79);
        margin-left: 50px;
        font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        font-weight: bold;
        font-size: 25px;

    }


    /* Main content container */
    .main-content {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        margin-top: 50px;
    }

    /* App information section */
    .app-info {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 30px;
    }

    /* Mobile picture */
    .mobile-picture img {
        width: 600px;
        /* Adjust as needed */
        height: 800px;
        /* Maintain aspect ratio */
        margin-left: 20px;
        /* Add space between mobile picture and QR code */
        margin-right: 200px;
    }

    /* QR code */
    .qr-code img {
        width: 250px;
        /* Adjust as needed */
        height: 250px;
        /* Maintain aspect ratio */
        margin-right: 20px;
        /* Add space between mobile picture and QR code */
        margin-left: 50px;
    }

    /* App links section */
    .app-links {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 50px;
    }

    .app-links img {
        height: 100px;
        width: 200px;
    }

/* CSS styles for the Screenshots and App Demo section */
.screenshots-demo {
    margin-top: 50px;
    text-align: center;
}

.screenshots-demo h2 {
    color: rgb(49, 16, 79);
    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    font-weight: bold;
    font-size: 25px;
}

.app-demo {
    display: flex;
    justify-content: center;
    margin-top: 30px;
}

.mobile-screenshots {
    margin-right: 20px;
}

.mobile-screenshots img {
    width: 200px; /* Adjust as needed */
    height: auto; /* Maintain aspect ratio */
    margin-bottom: 10px;
}

.app-video {
    max-width: 560px; /* Adjust as needed */
    margin-top: 20px; /* Added space */
}

.app-video iframe {
    width: 100%;
    height: 315px; /* Adjust as needed */
}

/* CSS styles for the Frequently Asked Questions (FAQs) section */
.faq {
    margin-top: 50px;
    text-align: center;
    margin-left: 40px;
    margin-right: 40px;
}

.faq h2 {
    color:brown;
    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    font-weight: bold;
    font-size: 25px;

}

.faq-item {
    margin-top: 20px;
    text-align: left;
    border-bottom: 1px solid #ccc; /* Add border between FAQ items */
    padding-bottom: 5px; /* Add padding at the bottom of each FAQ item */
    background-color: #f9f9f9; /* Background color for FAQ items */
    border-radius: 8px; /* Border radius for rounded corners */
}

.faq-item h3 {
    color: rgb(49, 16, 79);
    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    font-weight: bold;
    font-size: 20px;
    padding-top: 15px;
}

.faq-item p {
    color: rgb(49, 16, 79);
    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    font-size: 20px;
    line-height: 1.5;
    text-align: center;
}


    /* Footer */
    footer {
        position: relative;
        margin-top: 100px;
        background: #343434;
        padding-top: 10px;
    }

    .container {
        width: 1140px;
        margin: auto;
        display: flex;
        justify-content: center;
    }

    .footer-content {
        width: 35%;
    }

    h3 {
        font-size: 28px;
        margin-bottom: 15px;
        text-align: center;
        color: aqua;
    }

    .footer-content p {
        width: 190px;
        margin: auto;
        padding: 7px;
        color: white;
        font-size: 18px;
    }

    .footer-content ul {
        text-align: center;

    }

    .list {
        padding: 0;
    }

    .list li {
        width: auto;
        text-align: center;
        list-style-type: none;
        padding: 7px;
        position: relative;
        color: white;
    }

    .list li::before {
        content: '';
        position: absolute;
        transform: translate(-50%, -50%);
        left: 50%;
        top: 100%;
        width: 0;
        height: 2px;
        background: aqua;
        transition-duration: .5s;
    }

    .list li:hover::before {
        width: 70px;
    }

    .social-icons {
        text-align: center;
        padding: 0;
    }

    .social-icons li {
        display: inline-block;
        text-align: center;
        padding: 5px;
    }

    .social-icons i {
        color: white;
        font-size: 25px;
    }

    a {
        text-decoration: none;
    }

    a:hover {
        color: aqua;
    }

    .social-icons i:hover {
        color: aqua;
    }


    .go-top {
        position: absolute;
        top: 150px;
        left: 20px;
        background-color: aqua;
        color: rgb(0, 0, 0);
        border: none;
        padding: 10px 20px;
        cursor: pointer;
        border-radius: 5px;
    }

    .go-top:hover {
        background-color: rgb(33, 211, 211);
    }

    .bottom-bar {
        background: #6f6f6e;
        text-align: center;
        padding: 10px 0;
        margin-top: 50px;
    }

    .bottom-bar p {
        color: white;
        margin: 0;
        font-size: 16px;
        padding: 7px;
    }

    .bottom-bar a {
        color: white;
        text-decoration: none;
        margin: 0 30px;
        /* Increase the margin for more space between links */
    }

    .bottom-bar a:hover {
        text-decoration: underline;
    }
</style>