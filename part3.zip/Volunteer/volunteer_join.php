<?php
session_start();
include_once('../connection.php');

// Ensure the session variables are set
$_SESSION['name'];
$_SESSION['username'];
?>

<?php
// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'quickresq';

// Create a secure connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST["submit1"])) {
    $target_dir = "../Volunteer/uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check === false) {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    $allowedFormats = ["jpg", "jpeg", "png", "gif"];
    if (!in_array($imageFileType, $allowedFormats)) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        // Try to upload file
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // File uploaded successfully, now insert into database
            $image = basename($_FILES["image"]["name"]);
            $name = $_POST["name"];
            $address = $_POST["address"];
            $latitude = $_POST["latitude"];
            $longitude = $_POST["longitude"];
            $phoneNum = $_POST["phoneNum"];
            $blood_group = $_POST["blood_group"];
            $keywords = $_POST["keywords"];

            $sql = "INSERT INTO volunteer (image, name, address, latitude, longitude, phoneNum, blood_group, keywords) 
                    VALUES ('$image', '$name', '$address','$latitude', '$longitude', '$phoneNum', '$blood_group', '$keywords')";
            if ($conn->query($sql) === true) {
                echo "<script>alert('Successfully INSERT')</script>";
                header('Location: admin_volunteer.php');
                exit();
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}
// Get form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $address = $_POST["address"];
    $latitude = $_POST["latitude"];
    $longitude = $_POST["longitude"];
    $phoneNum = $_POST["phoneNum"];
    $blood_group = $_POST["blood_group"];
    $keywords = $_POST["keywords"];
    $image = $_FILES["image"]["name"];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);

    // Validate user input
    if (empty($name) || empty($address) || empty($phoneNum) || empty($blood_group) || empty($keywords)) {
        echo "Please fill in all fields";
        exit;
    }

    // Check for duplicate entries
    $stmt = $conn->prepare("SELECT COUNT(*) FROM volunteer WHERE phoneNum = ?");
    $stmt->bind_param("s", $phoneNum);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        echo "<script>
        alert('A record with similar details already exists.\\nTRY SOMETHING NEW.'); 
        setTimeout(function(){ window.location.href = 'volunteer_join.php'; }, 100);
        </script>";
        exit;
    }

    // Move uploaded file to target directory
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO volunteer (image, name, phoneNum, address, latitude, longitude, blood_group, keywords) VALUES (?, ?, ?, ?, ?, ?,?,?)");
        $stmt->bind_param("ssssssss", $image, $name, $phoneNum, $address, $latitude, $longitude, $blood_group, $keywords);

        // Execute the prepared statement
        if ($stmt->execute()) {
            echo "Record inserted successfully";
            header('Location: volunteer_join.php');
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error uploading file.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - Volunteer Join</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link href="volunteer_join.css" rel="stylesheet" type="text/css">
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>
</head>

<body>
    <!-- Add the top navigation here -->

    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>

    <header>
        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo" /></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Hospital</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="#">Volunteer</a>
                            <ul class="sub-menu">
                                <li><a href="volunteer.php">Search</a></li>
                            </ul>
                        </li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="../EmergencyRequest/emergency_request_form.php">Need Help</a></li>
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <div>
        <form action="volunteer_join.php" method="post" enctype="multipart/form-data" autocomplete="off">
            <h3 class="title">Join as a Volunteer</h3>

            <div class="input-container">
                <label for="image">Image</label>
                <input type="file" name="image" class="input" />
            </div>

            <div class="input-container">
                <label for="name">Name<span class="required">*</span></label>
                <input type="text" name="name" class="input" placeholder="e.g. John Doe" required />
            </div>

            <div class="input-container">
                <label for="phoneNum">Phone Number<span class="required">*</span></label>
                <input type="text" name="phoneNum" class="input" placeholder="e.g. 0123456789" required />
            </div>

            <div class="input-container">
                <label for="address">Address<span class="required">*</span></label>
                <input type="text" id="address" name="address" class="input" placeholder="e.g. Secretariat Road, Central Shaeed Minar Area, Shahbagh, Dhaka" required />
                <button type="button" onclick="convertAddress()">Write Your Address & Click Me<span class="required">*</span></button>
            </div>

            <div class="input-container">
                <input type="hidden" id="latitude" name="latitude" class="input" placeholder="You can read only. It's Automatically Get from the Address" required readonly />
            </div>

            <div class="input-container">
                <input type="hidden" id="longitude" name="longitude" class="input" placeholder="You can read only. It's Automatically Get from the Address" required readonly />
            </div>

            <div class="input-container">
                <label for="blood_group">Blood Group<span class="required">*</span></label>
                <select name="blood_group" id="blood_group" class="input" required>
                    <option value="" disabled selected>Select Your Blood Group</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="All">All</option>
                </select>
            </div>

            <div class="input-container">
                <label for="keywords">Keywords [separated by comma]<span class="required">*</span></label>
                <input type="text" name="keywords" class="input" placeholder="e.g. Dhaka, Puran Dhaka, Dhanmondi, Gulshan" required />
            </div>

            <input type="submit" value="Join" class="btn" />
        </form>
    </div>


    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email:quickresq@info.org.bd</p>
                <p>Phone:+123 456 789</p>
                <p>Address:B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>

    </footer>


    <script>
        function convertAddress() {
            var address = document.getElementById('address').value;
            var apiKey = '7bc38d22cc91438eb42f41ed38e0197f';
            var url = `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(address)}&key=${apiKey}`;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.results.length > 0) {
                        var lat = data.results[0].geometry.lat;
                        var lng = data.results[0].geometry.lng;
                        document.getElementById('latitude').value = lat;
                        document.getElementById('longitude').value = lng;
                    } else {
                        alert('Please Write Your Address then Click. \n No results found');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error fetching coordinates');
                });
        }
    </script>

</body>

</html>