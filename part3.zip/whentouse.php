<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>


<!doctype html>
<html lang="en">

<head>
    <title>QuickResQ - When to Use?</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="Image/QuickResQ_icon.png" type="image/x-icon" />
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>

</head>


<body>
    <!-- Add the top navigation here -->

    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>


    <header>

        <div class="logo">
            <a href="index.php"><img src="Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="Hospital/hospital.php">Hospital</a></li>
                        <li><a href="Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="Blood/blood.php">Blood</a></li>
                        <li><a href="PoliceStation/police.php">Police Station</a></li>
                        <li><a href="FireService/fireService.php">Fire Services</a></li>
                        <li><a href="Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="EmergencyRequest/emergency_request_form.php">Need Help</a></li>
                <li><a href="IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="Login_Register/logout.php"><img src="Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <div class="content">
        <!-- Question and Answer Section -->
        <div class="question">
            <h1>When to use QuickResQ?</h1>
            <p>QuickResQ is a versatile platform that can be used in various emergency situations:</p>
            <ul>
                <li>In case of medical emergencies, such as accidents or sudden illness, use the
                    <strong>Ambulance</strong> feature to quickly locate and request emergency medical assistance.
                </li>
                <li>When you need to find the nearest medical facilities, including hospitals and clinics, utilize the
                    <strong>Find Hospital</strong> feature.
                </li>
                <li>If you require blood for a medical procedure or emergency transfusion, use the <strong>Find
                        Blood</strong> feature to connect with blood donors in your area.</li>
                <li>For fire-related emergencies, such as building fires or wildfires, access the <strong>Fire
                        Service</strong> feature to report incidents and request assistance from firefighters.</li>
                <li>In situations requiring police intervention or assistance, use the <strong>Police Station</strong>
                    feature to locate nearby police stations and contact law enforcement authorities.</li>
                <li>For immediate first aid guidance and tips on handling common medical emergencies, refer to the
                    <strong>First Aid Tips</strong> feature for valuable information.
                </li>
            </ul>
        </div>

        <!-- Icons Section -->
        <div class="icons-container">
            <div class="row">
                <div class="icon">
                    <img src="Image/whentouse/ambulance.png" alt="Ambulance">
                    <p>Ambulance</p>
                </div>
                <div class="icon">
                    <img src="Image/whentouse/hospital.png" alt="Hospital">
                    <p>Hospital</p>
                </div>
                <div class="icon">
                    <img src="Image/whentouse/findblood.png" alt="Blood">
                    <p>Find Blood</p>
                </div>
            </div>
            <div class="row">
                <div class="icon">
                    <img src="Image/whentouse/fireservice.png" alt="Fire Service">
                    <p>Fire Service</p>
                </div>
                <div class="icon">
                    <img src="Image/whentouse/police.png" alt="Police Station">
                    <p>Police Station</p>
                </div>
                <div class="icon">
                    <img src="Image/whentouse/fastaid.png" alt="First Aid Tips">
                    <p>First Aid Tips</p>
                </div>
            </div>
        </div>

    </div>



    <div class="faq-section">
        <h2>Frequently Asked Questions</h2>
        <div class="faq-item">
            <h3 class="faq-question">What is QuickResQ?</h3>
            <div class="faq-answer" style="display: none;">
                <p>QuickResQ is a versatile emergency support system designed to provide assistance in various emergency
                    situations such as medical emergencies, fire incidents, and police interventions.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">How do I use QuickResQ?</h3>
            <div class="faq-answer" style="display: none;">
                <p>To use QuickResQ, simply navigate to the desired service from the menu and follow the instructions
                    provided. For example, to request an ambulance, click on the "Emergency Ambulance" service and enter
                    your location details.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">How does QuickResQ help during medical emergencies?</h3>
            <div class="faq-answer" style="display: none;">
                <p>QuickResQ provides a platform for users to quickly locate and request emergency medical assistance,
                    connect with nearby hospitals, find blood donors, and access first aid guidance, all aimed at
                    facilitating timely help during medical emergencies.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">Can I find the nearest hospital using QuickResQ?</h3>
            <div class="faq-answer" style="display: none;">
                <p>Yes, QuickResQ offers a feature to locate and access information about the nearest hospitals and
                    medical facilities based on the user's current location, ensuring quick access to medical care in
                    emergencies.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">How does QuickResQ assist in finding blood donors?</h3>
            <div class="faq-answer" style="display: none;">
                <p>QuickResQ allows users to search for blood donors in their area based on blood type and location,
                    facilitating the process of finding and connecting with potential donors during urgent blood
                    transfusion needs.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">What services does QuickResQ offer for fire-related emergencies?</h3>
            <div class="faq-answer" style="display: none;">
                <p>QuickResQ provides a feature to report fire-related emergencies, including building fires and
                    wildfires, enabling users to quickly alert authorities and request assistance from firefighters in
                    such situations.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">Is it possible to locate nearby police stations using QuickResQ?</h3>
            <div class="faq-answer" style="display: none;">
                <p>Yes, QuickResQ includes a feature to locate nearby police stations based on the user's current
                    location, allowing users to quickly access law enforcement assistance and resources when needed.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">How does QuickResQ provide first aid guidance?</h3>
            <div class="faq-answer" style="display: none;">
                <p>QuickResQ offers comprehensive first aid guidance and tips for handling common medical emergencies,
                    providing users with valuable information and instructions to administer immediate aid until
                    professional medical help arrives.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">Can I request an emergency ambulance through QuickResQ?</h3>
            <div class="faq-answer" style="display: none;">
                <p>Absolutely! QuickResQ allows users to request emergency ambulance services directly through the app,
                    ensuring prompt dispatch of medical assistance to the user's location in critical situations.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">Is QuickResQ available for both Android and iOS devices?</h3>
            <div class="faq-answer" style="display: none;">
                <p>Yes, QuickResQ is available for both Android and iOS devices, allowing users across different
                    platforms to access its features and services seamlessly.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">How do I download QuickResQ from the Google Play Store?</h3>
            <div class="faq-answer" style="display: none;">
                <p>You can download QuickResQ from the Google Play Store by searching for "QuickResQ" in the store's
                    search bar and selecting the app from the search results. Then, simply click on the "Install" button
                    to download and install the app on your device.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">What features are included in the QuickResQ mobile app?</h3>
            <div class="faq-answer" style="display: none;">
                <p>The QuickResQ mobile app includes features such as emergency ambulance request, hospital and medical
                    facility locator, blood donor search, fire service reporting, police station locator, and
                    comprehensive first aid guidance.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">Does QuickResQ offer real-time updates during emergencies?</h3>
            <div class="faq-answer" style="display: none;">
                <p>Yes, QuickResQ provides real-time updates and notifications during emergencies, keeping users
                    informed about the status of their requests and providing relevant information and instructions as
                    needed.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question">How does QuickResQ ensure user privacy and data security?</h3>
            <div class="faq-answer" style="display: none;">
                <p>QuickResQ takes user privacy and data security seriously, implementing robust measures such as
                    encryption, secure authentication, and stringent data protection protocols to safeguard user
                    information and ensure confidentiality.</p>
            </div>
        </div>









    </div>

<!-- Footer -->
<footer>
    <div class="container">
      <div class="footer-content">
        <h3>Contact Us</h3>
        <p>Email:quickresq@info.org.bd</p>
        <p>Phone:+123 456 789</p>
        <p>Address:B/7, Gulshan 2, Dhaka 1212</p>
      </div>
      <div class="footer-content">
        <h3>Quick Links</h3>
        <ul class="list">
          <li><a href="index.php">Home</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li><a href="mobileapp.php">Mobile App</a></li>
          <li><a href="ContactUs/contactus.php">Contact Us</a></li>
          <li><a href="User_Review&Rating/index.php">Reviews</a></li>
        </ul>
      </div>
      <div class="footer-content">
        <h3>Follow Us</h3>
        <ul class="social-icons">
          <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
          <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
          <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
          <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
        </ul>
      </div>
      <button class="go-top" onclick="scrollToTop()">Go to Top</button>
      <script>
        function scrollToTop() {
          window.scrollTo({
            top: 0,
            behavior: 'smooth'
          });
        }
      </script>
    </div>
    <div class="bottom-bar">
      <p>
        <a href="footer_assets/privacy_policy.html">Privacy Policy</a> ||
        <a href="footer_assets/copyright_policy.html">Copyright Policy</a> ||
        <a href="footer_assets/terms_conditions.html">Terms & Conditions</a> ||
                 &copy; 2024 QuickResQ. All rights reserved.
      </p>
    </div>

  </footer>
</body>

</html>







<style>
    body {
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
        overflow-x: hidden;
        /* Prevent horizontal scrolling */
    }

    .marquee {
        display: flex;
        overflow: hidden;
        width: 200px;
        /* Set the desired width */
        padding: 2px 4px;
        color: #c62828;
    }

    .marquee>* {
        white-space: nowrap;
        /* Prevent content from wrapping */
    }

    @keyframes marquee {
        from {
            transform: translateX(100%);
            /* Start from the right end */
        }

        to {
            transform: translateX(-100%);
            /* End at the left end */
        }
    }

    .marquee>* {
        animation: marquee 7s linear infinite;
    }

    .logo {
        flex: 0 0 auto;
        position: relative;
        top: 10px;
        left: 40px;
    }

    .logo img {
        top: 10px;
        width: 190px;
        height: 80px;
        border-radius: 5px;
    }

    .flag {
        flex: 0 0 auto;
        max-height: 100px;
        /* Maintain aspect ratio */
        max-width: 180px;
        margin-right: 200px;
        /* Adjust margin as needed */
        float: right;
    }

    #buttonStyle {
        position: relative;
        top: 30px;
        z-index: 100;
        background-color: #ccc4c4;
        height: 50px;
        width: 100%;
        display: flex;
        justify-content: flex-start;
        /* Align items to the left */
        align-items: center;
        /* Vertically center the items */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        /* Apply box-shadow to the navbar */
    }

    #buttonStyle ul {
        list-style: none;
        margin: 0;
        display: flex;
        /* Align items in a row */
    }

    #buttonStyle ul li {
        border-radius: 5px;
        border: 1px solid transparent;
        margin: 0 10px;
        /* Adjust margin between buttons */
        height: 40px;
        /* Set the height of the button */
        line-height: 40px;
        /* Vertically center the text */
        font-family: Arial;
        position: relative;
    }

    #buttonStyle ul li a {
        font-size: 16px;
        font-weight: bold;
        font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        text-decoration: none;
        color: rgb(40, 35, 63);
        display: block;
        width: 120px;
        /* Set the width of the button */
        text-align: center;
        /* Center the text horizontally */
    }

    #buttonStyle ul li a:hover {
        border-radius: 5px;
        box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
        /* Move box-shadow above the navbar */
        border: 1px solid #ccc;
        /* Add a border to the button on hover */
    }

    #buttonStyle ul li a:active {
        position: relative;
    }

    #buttonStyle ul ul {
        margin: 0px;
        padding: 2px;
        position: absolute;
        display: none;
        background-color: #ccc4c4;
    }

    #buttonStyle ul li:hover>ul {
        display: block;
    }

    #buttonStyle ul ul li {
        width: 120px;
        margin: 4px;
    }

    /* Position the logout button to the right */
    #buttonStyle ul li#logout {
        margin-left: 280px;
        /* Push logout button to the right */
    }


    /* Additional styling for the logout image */
    #buttonStyle ul li#logout img.logout {
        width: 30px;
        /* Set the width of the image */
        height: 30px;
        /* Set the height of the image */
        margin: 4px;
    }


    .content {
        margin-top: 50px;
        padding: 20px;
    }

    .question {
        text-align: left;
        margin-bottom: 20px;
        margin-left: 40px;

    }

    .question h1 {
        font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        color: #4d23a0;
    }

    .question p {
        font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        color: #160832;
        ;
        font-size: 20px;
    }

    .question li {
        font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        color: #160832;
        ;
        font-size: 20px;
        line-height: 25px;
    }


    .icons-container {
        margin-left: 200px;
        margin-right: 200px;
        margin-top: 50px;
    }

    .row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 50px;
    }

    .icon {
        text-align: center;
        margin: 10px;
    }

    .icon img {
        width: 120px;
        height: 120px;
        border-radius: 20%;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        /* Add shadow effect */

    }

    .icon p {
        margin-top: 5px;
        font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
        font-size: 25px;
        font-weight: lighter;
        color: dimgrey;
    }



    /* CSS for FAQ section */
    .faq-section {
        margin-top: 50px;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    .faq-section h2 {
        margin-bottom: 20px;
        background-color: #333;
        color: #fff;
        padding: 10px 20px;
        border-radius: 5px;
        display: inline-block;
    }

    .faq-item {
        margin-bottom: 20px;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        text-align: left;
    }

    .faq-question {
        cursor: pointer;
        font-size: 20px;
        font-weight: bold;
        text-align: left;
        color: #1b4b82;
        margin-top: 5px;
    }

    .faq-answer {
        display: none;
        color: #464646;
        margin-top: 10px;
        font-size: 20px;
    }

/* Footer */
footer {
    position: relative;
    margin-top: 100px;
    background: #343434;
    padding-top: 10px;
}

.container {
    width: 1140px;
    margin: auto;
    display: flex;
    justify-content: center;
}

.footer-content {
    width: 35%;
}

h3 {
    font-size: 28px;
    margin-bottom: 15px;
    text-align: center;
    color: aqua;
}

.footer-content p {
    width: 190px;
    margin: auto;
    padding: 7px;
    color: white;
    font-size: 18px;
}

.footer-content ul {
    text-align: center;

}

.list {
    padding: 0;
}

.list li {
    width: auto;
    text-align: center;
    list-style-type: none;
    padding: 7px;
    position: relative;
    color: white;
}

.list li::before {
    content: '';
    position: absolute;
    transform: translate(-50%, -50%);
    left: 50%;
    top: 100%;
    width: 0;
    height: 2px;
    background: aqua;
    transition-duration: .5s;
}

.list li:hover::before {
    width: 70px;
}

.social-icons {
    text-align: center;
    padding: 0;
}

.social-icons li {
    display: inline-block;
    text-align: center;
    padding: 5px;
}

.social-icons i {
    color: white;
    font-size: 25px;
}

a {
    text-decoration: none;
}

a:hover {
    color: aqua;
}

.social-icons i:hover {
    color: aqua;
}


.go-top {
    position: absolute;
    top: 150px;
    left: 20px;
    background-color: aqua;
    color: rgb(0, 0, 0);
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
}

.go-top:hover {
    background-color: rgb(33, 211, 211);
}

.bottom-bar {
    background: #6f6f6e;
    text-align: center;
    padding: 10px 0;
    margin-top: 50px;
}

.bottom-bar p {
    color: white;
    margin: 0;
    font-size: 16px;
    padding: 7px;
}

.bottom-bar a {
    color: white;
    text-decoration: none;
    margin: 0 30px; /* Increase the margin for more space between links */
}

.bottom-bar a:hover {
    text-decoration: underline;
}

</style>


<script>
    // JavaScript for FAQ functionality
    document.addEventListener('DOMContentLoaded', function() {
        const faqQuestions = document.querySelectorAll('.faq-question');

        faqQuestions.forEach(function(question) {
            question.addEventListener('click', function() {
                const answer = this.nextElementSibling;

                // Toggle answer visibility
                if (answer.style.display === 'none') {
                    answer.style.display = 'block';
                } else {
                    answer.style.display = 'none';
                }
            });
        });
    });
</script>