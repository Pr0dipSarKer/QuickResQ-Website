<?php
session_start();
include_once('connection.php');

// Ensure the correct content type is set
header('Content-Type: application/json');

// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'quickresq';

// Create a secure connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch statistics
$sql = "SELECT name, value FROM statistics";
$result = $conn->query($sql);

$statistics = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $statistics[] = $row;
    }
}

$conn->close();

echo json_encode($statistics);
?>
