<?php
session_start();
include_once('connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>

<!doctype html>
<html lang="en">

<head>
  <title>QuickResQ - Home</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" href="Image/QuickResQ_icon.png" type="image/x-icon" />
  <link href="style.css" rel="stylesheet" type="text/css">
  <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">

</head>

<body>
  <!-- Add the top navigation here -->

  <div class="marquee">
    <span>Welcome <?= isset($_SESSION['name']) ? $_SESSION['name'] : 'Guest'; ?> to QuickResQ</span>
  </div>

  <header>
    <div class="logo">
      <img src="Image/QuickResQ_logo.png" class="logo" alt="My Logo">
      <img src="Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
    </div>

    <div id="buttonStyle">
      <div class="nav-container">
        <div class="hamburger-menu" id="hamburgerMenu">
          &#9776; <!-- Unicode for the hamburger icon -->
        </div>
        <ul id="navList">
          <li><a href="index.php">Home</a></li>
          <li><a href="whentouse.php">When to Use?</a></li>
          <li><a href="#">Services</a>
            <ul style="list-style: none;">
              <li><a href="Hospital/hospital.php">Hospital</a></li>
              <li><a href="Ambulance/ambulance.php">Ambulance</a></li>
              <li><a href="Blood/blood.php">Blood</a></li>
              <li><a href="PoliceStation/police.php">Police Station</a></li>
              <li><a href="FireService/fireService.php">Fire Services</a></li>
              <li><a href="Volunteer/volunteer.php">Volunteer</a></li>
              <li><a href="Fastaid/fastaid.php">First Aid Guide</a></li>
            </ul>
          </li>
          <li><a href="EmergencyRequest/emergency_request_form.php">Need Help</a></li>
          <li><a href="IncidentReports/incident_reports.php">Incidents</a></li>
          <li><a href="mobileapp.php">Mobile App</a></li>
          <li><a href="#">About</a>
            <ul style="list-style: none;">
              <li><a href="aboutus.php">About Us</a></li>
              <li><a href="ContactUs/contactus.php">Contact Us</a></li>
              <li><a href="User_Review&Rating/index.php">Reviews</a></li>
            </ul>
          </li>
          <li id="logout"><a href="Login_Register/logout.php"><img src="Image/logout.png" class="logout" alt="logout"></a></li>
        </ul>
      </div>
    </div>
  </header>

  <div class="slideshow-container">
    <!-- Slideshow images -->
    <div class="mySlides fade">
      <div class="numbertext">1 / 6</div>
      <img src="Image/banner/QuickResQ - Ambulance.png" style="width:100%">
      <div class="text">Emergency Ambulance: Here When You Need Us Most</div>
    </div>
    <div class="mySlides fade">
      <div class="numbertext">2 / 6</div>
      <img src="Image/banner/QuickResQ - Hospital.png" style="width:100%">
      <div class="text">Immediate Medical Attention for Urgent Needs</div>
    </div>
    <div class="mySlides fade">
      <div class="numbertext">3 / 6</div>
      <img src="Image/banner/QuickResQ_-_Blood.png" style="width:100%">
      <div class="text">Donate Blood, Save Lives</div>
    </div>
    <div class="mySlides fade">
      <div class="numbertext">4 / 6</div>
      <img src="Image/banner/QuickResQ_-_police-transformed.png" style="width:100%">
      <div class="text">Police On Duty: Here to Protect and Serve</div>
    </div>
    <div class="mySlides fade">
      <div class="numbertext">5 / 6</div>
      <img src="Image/banner/QuickResQ_-_fireservice-transformed.png" style="width:100%">
      <div class="text">Fire Emergencies ? FireFighters : Rapid Response, Reliable Rescue</div>
    </div>
    <div class="mySlides fade">
      <div class="numbertext">6 / 6</div>
      <img src="Image/banner/QuickResQ_-_Fast_Aid-transformed.png" style="width:100%">
      <div class="text">First Aid Tips: Immediate Help When You Need It</div>
    </div>

    <a class="prev" onclick="plusSlides(-1)">❮</a>
    <a class="next" onclick="plusSlides(1)">❯</a>
  </div>
  <br>
  <div style="text-align:center">
    <span class="dot" onclick="currentSlide(1)"></span>
    <span class="dot" onclick="currentSlide(2)"></span>
    <span class="dot" onclick="currentSlide(3)"></span>
  </div>

  <script>
    let slideIndex = 0;
    showSlides();

    function showSlides() {
      let i;
      let slides = document.getElementsByClassName("mySlides");
      let dots = document.getElementsByClassName("dot");
      for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
      }
      slideIndex++;
      if (slideIndex > slides.length) {
        slideIndex = 1
      }
      for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
      }
      slides[slideIndex - 1].style.display = "block";
      dots[slideIndex - 1].className += " active";
      setTimeout(showSlides, 3000); // Change image every 3 seconds
    }

    function plusSlides(n) {
      slideIndex += n - 1;
      showSlides();
    }

    function currentSlide(n) {
      slideIndex = n - 1;
      showSlides();
    }

    // there is the code for hamburger 
    document.getElementById("hamburgerMenu").addEventListener("click", function() {
      var navList = document.getElementById("navList");
      if (navList.style.display === "flex") {
        navList.style.display = "none";
      } else {
        navList.style.display = "flex";
      }
    });

    // Handle submenu toggle on smaller screens
    document.querySelectorAll('#navList > li > a').forEach(function(menuItem) {
      menuItem.addEventListener('click', function(event) {
        var submenu = this.nextElementSibling;
        if (submenu && submenu.tagName === 'UL') {
          event.preventDefault();
          if (submenu.style.display === 'block') {
            submenu.style.display = 'none';
          } else {
            submenu.style.display = 'block';
          }
        }
      });
    });
  </script>

  <div class="info-container">
    <h2>QuickResQ</h2>
    <p>QuickResQ is an initiative envisioned by us to establish an integrated emergency response system with a single point of contact designed to address various emergencies faced by citizens.
      QuickResQ is designed to handle all emergency signals received from citizens through voice calls, SMS, emails, panic SOS signals, the QuickResQ web portal, and other channels.
      To facilitate quick assistance during emergencies, we introduced a mobile app called 'QuickResQ'. This app allows individuals to swiftly request help by pressing a button, which
      sends alert messages containing location data and enables emergency calls, allowing relevant service agencies to respond promptly to requests for assistance.
    </p>
  </div>

  <div class="container-wrapper">
    <div class="article-container">
      <!-- Embed YouTube video -->
      <div class="video-wrapper">
        <iframe width="100%" height="315" src="https://www.youtube.com/embed/kNH_351CFWU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
    <div class="photo-container">
      <img src="Image/Bangladeshi_map.png" alt="Photo">
    </div>
  </div>

  <!-- Key Features Section -->
  <div class="features-container">
    <h2>Key Features</h2>
    <div class="features-content">
      <div class="feature">
        <i class="fas fa-ambulance"></i>
        <h3>Emergency Ambulance</h3>
        <p>Rapid response and immediate medical attention in case of emergencies.</p>
      </div>
      <div class="feature">
        <i class="fas fa-hospital"></i>
        <h3>Hospital Services</h3>
        <p>Quick access to nearby hospitals for urgent medical care.</p>
      </div>
      <div class="feature">
        <i class="fas fa-tint"></i>
        <h3>Blood Donation</h3>
        <p>Facilitating blood donations and ensuring availability of blood for patients.</p>
      </div>
      <div class="feature">
        <i class="fas fa-shield-alt"></i>
        <h3>Police Assistance</h3>
        <p>Immediate police assistance in case of any emergency situation.</p>
      </div>
      <div class="feature">
        <i class="fas fa-fire-extinguisher"></i>
        <h3>Fire Services</h3>
        <p>Quick response to fire emergencies to ensure safety and protection.</p>
      </div>
      <div class="feature">
        <i class="fas fa-first-aid"></i>
        <h3>First Aid Guide</h3>
        <p>Comprehensive guide to provide immediate first aid in various situations.</p>
      </div>
    </div>
  </div>
  <!-- Statistics Section -->
  <div class="statistics-container">
    <h2>Our Impact</h2>
    <div class="statistics-content">
      <div class="statistic red">
        <i class="fas fa-ambulance"></i>
        <h3 id="stat1">0</h3>
        <p>Emergencies Handled</p>
      </div>
      <div class="statistic green">
        <i class="fas fa-tint"></i>
        <h3 id="stat2">0</h3>
        <p>Blood Donations</p>
      </div>
      <div class="statistic blue">
        <i class="fas fa-life-ring"></i>
        <h3 id="stat3">0</h3>
        <p>Rescue Operations</p>
      </div>
      <div class="statistic yellow">
        <i class="fas fa-hands-helping"></i>
        <h3 id="stat4">0</h3>
        <p>Volunteers Engaged</p>
      </div>
      <div class="statistic gray">
        <i class="fas fa-chalkboard-teacher"></i>
        <h3 id="stat5">0</h3>
        <p>Training Sessions Conducted</p>
      </div>
    </div>
  </div>

  <!-- News & Updates Section -->
  <div class="news-updates-container">
    <h2>News & Updates</h2>
    <div class="news-updates-content">
      <div class="news-item">
        <h3>New Mobile App Launched</h3>
        <p>We are excited to announce the launch of our new mobile app for better emergency response. The app offers real-time tracking of emergency services, making it easier for users to receive timely assistance.</p>
      </div>
      <div class="news-item">
        <h3>Partnership with Local Hospitals</h3>
        <p>QuickResQ has partnered with several local hospitals to provide quicker access to medical services. This collaboration aims to enhance the efficiency and speed of emergency response teams.</p>
      </div>
      <div class="news-item">
        <h3>Upcoming Blood Donation Camp</h3>
        <p>Join us for the upcoming blood donation camp to help save lives. The event will be held at the City Hall on August 15th. All donors will receive a free health check-up.</p>
      </div>
      <div class="news-item">
        <h3>Emergency Contact Alert System Added</h3>
        <p>QuickResQ now features an Emergency Contact Alert System. Users can add emergency contacts who will be notified automatically in case of an emergency via SMS or email alerts.</p>
      </div>
      <div class="news-item">
        <h3>Real-Time Location Tracking Introduced</h3>
        <p>We have implemented a real-time location tracking system for emergency services, allowing users to see the real-time location of the nearest available emergency service vehicle and get an estimated time of arrival.</p>
      </div>
      <!-- Add more news items as needed -->
    </div>
  </div>


  <!-- Footer -->
  <footer>
    <div class="container">
      <div class="footer-content">
        <h3>Contact Us</h3>
        <p>Email: quickresq@info.org.bd</p>
        <p>Phone: +123 456 789</p>
        <p>Address: B/7, Gulshan 2, Dhaka 1212</p>
      </div>
      <div class="footer-content">
        <h3>Quick Links</h3>
        <ul class="list">
          <li><a href="index.php">Home</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li><a href="mobileapp.php">Mobile App</a></li>
          <li><a href="ContactUs/contactus.php">Contact Us</a></li>
          <li><a href="User_Review&Rating/index.php">Reviews</a></li>
        </ul>
      </div>
      <div class="footer-content">
        <h3>Follow Us</h3>
        <ul class="social-icons">
          <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
          <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
          <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
          <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
        </ul>
      </div>
      <button class="go-top" onclick="scrollToTop()">Go to Top</button>
      <script>
        function scrollToTop() {
          window.scrollTo({
            top: 0,
            behavior: 'smooth'
          });
        }
      </script>
    </div>
    <div class="bottom-bar">
      <p>
        <a href="footer_assets/privacy_policy.html">Privacy Policy</a> ||
        <a href="footer_assets/copywrite_policy.html">Copyright Policy</a> ||
        <a href="footer_assets/terms&conditions.html">Terms & Conditions</a> ||
        &copy; 2024 QuickResQ. All rights reserved.
      </p>
    </div>
  </footer>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      fetch('getStatistics.php')
        .then(response => response.json())
        .then(data => {
          const statisticsContent = document.querySelector('.statistics-content');
          statisticsContent.innerHTML = ''; // Clear any existing content

          data.forEach((stat, index) => {
            const statElement = document.createElement('div');
            statElement.className = 'statistic';
            statElement.innerHTML = `
                            <h3>${stat.value}</h3>
                            <p>${stat.name}</p>
                        `;
            statisticsContent.appendChild(statElement);
          });
        })
        .catch(error => console.error('Error fetching statistics:', error));
    });
  </script>
</body>

</html>