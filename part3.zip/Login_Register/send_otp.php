<?php
session_start();
include_once('connection.php');
require '/Xampp/htdocs/QuickResQ/includes/vendor/autoload.php';  // Make sure you have Composer's autoload file included

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['username'];
    $password = md5($_POST['password']);

    // Generate OTP
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['name'] = $name;
    $_SESSION['email'] = $email;
    $_SESSION['password'] = $password;

    // Send OTP
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Set the SMTP server to send through
        $mail->SMTPAuth = true;
        $mail->Username = 'quickresq.ess.org.bd@gmail.com'; // SMTP username
        $mail->Password = 'hpkq dfdu ilak ahiz'; // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        //Recipients
        $mail->setFrom('quickresq.ess.org.bd@gmail.com', 'QuickResQ');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body    = 'Your OTP for registration is ' . $otp;

        $mail->send();
        header('Location: verify_otp.php');
        exit;
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
