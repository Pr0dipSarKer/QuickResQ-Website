<?php
session_start();
if (isset($_POST['verify'])) {
    $otp = $_POST['otp'];
    if ($otp == $_SESSION['otp']) {
        include_once('connection.php');

        $name = $_SESSION['name'];
        $email = $_SESSION['email'];
        $password = $_SESSION['password'];

        $sql = "INSERT INTO `tbl_user` (`name`, `username`, `password`) VALUES ('$name', '$email', '$password')";
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Registration successful!');</script>";
            header('Location: login.php');
            exit;
        } else {
            echo "<script>alert('Something went wrong, please try again.');</script>";
        }
    } else {
        echo "<script>alert('Invalid OTP, please try again.');</script>";
    }
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>QuickResQ - Verify OTP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
</head>

<body>
  <section class="vh-100" style="background-color: #eee;">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-lg-12 col-xl-11">
          <div class="card text-black" style="border-radius: 25px;">
            <div class="card-body p-md-2">
              <div class="row justify-content-center">
                <p class="text-center h1 fw-bold mb-4 mx-1 mx-md-3 mt-3">Verify OTP</p>
                <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">
                  <form class="mx-1 mx-md-4" action="verify_otp.php" method="post">
                    <div class="d-flex flex-row align-items-center mb-4">
                      <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                      <div class="form-outline flex-fill mb-0">
                        <label class="form-label" for="otp"><i class="bi bi-lock-fill"></i> Enter OTP</label>
                        <input type="text" id="otp" class="form-control form-control-lg py-3" name="otp" autocomplete="off" placeholder="enter OTP" style="border-radius:25px ;" required/>
                      </div>
                    </div>
                    <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                      <input type="submit" value="Verify" name="verify" class="btn btn-warning btn-lg text-light my-2 py-3" style="width:100% ; border-radius: 30px; font-weight:600;" />
                    </div>
                  </form>
                </div>
                <div class="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">
                  <img src="verify_otp.png" class="img-fluid" alt="Sample image" height="300px" width="500px">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"></script>
</body>
</html>
