<?php
session_start();
include_once('connection.php');
require '../includes/PHPMailer/src/Exception.php';
require '../includes/PHPMailer/src/PHPMailer.php';
require '../includes/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['forgot_password'])) {
    $username = $_POST['username'];

    if (empty($username)) {
        echo "<script>alert('Please fill in your Email');</script>";
        exit;
    }

    // Check if the user exists
    $sql = "SELECT * FROM `tbl_user` WHERE `username`='$username'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // User found, generate a reset token
        $reset_token = bin2hex(random_bytes(32));
        $sql = "UPDATE `tbl_user` SET `reset_token`='$reset_token' WHERE `username`='$username'";
        mysqli_query($conn, $sql);

        // Send email with PHPMailer
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->SMTPDebug = 0;                                       // Disable verbose debug output
            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'quickresq.ess.org.bd@gmail.com';               // SMTP username
            $mail->Password   = 'hpkq dfdu ilak ahiz';                  // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption
            $mail->Port       = 587;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('quickresq.ess.org.bd@gmail.com', 'QuickResQ');
            $mail->addAddress($username);                               // Add a recipient

            // Content
            $mail->isHTML(true);                                        // Set email format to HTML
            $mail->Subject = 'Password Reset';
            // Generate reset link with token
            $reset_link = "http://yourwebsite.com/reset_password.php?token=$reset_token";
            $mail->Body    = "Click <a href='$reset_link'>here</a> to reset your password.";

            $mail->send();
            echo "<script>alert('Password reset link has been sent to your email');</script>";
        } catch (Exception $e) {
            echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
        }
    } else {
        echo "<script>alert('No user found with this email address');</script>";
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <title>Forgot Password</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />

</head>

<body>
    <section class="vh-100">
        <div class="container py-5 h-100">
            <div class="row d-flex align-items-center justify-content-center h-100">
                <div class="col-md-8 col-lg-7 col-xl-6">
                    <img src="forgot_password.png" class="img-fluid" alt="Forgot Password image" height="300px" width="600px">
                </div>
                <div class="col-md-7 col-lg-5 col-xl-5 offset-xl-1">
                    <form action="forgot_password.php" method="post">
                        <p class="text-center h1 fw-bold mb-4 mx-1 mx-md-3 mt-3">Forgot Password</p>
                        <!-- Email input -->
                        <div class="form-outline mb-4">
                            <label class="form-label" for="form1Example13"><i class="bi bi-envelope"></i> E-mail</label>
                            <input type="email" id="form1Example13" class="form-control form-control-lg py-3" name="username" autocomplete="off" placeholder="Enter your e-mail" style="border-radius:25px ;" />
                        </div>
                        <!-- Submit button -->
                        <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                            <input type="submit" value="Send Reset Link" name="forgot_password" class="btn btn-warning btn-lg text-light my-2 py-3" style="width:100% ; border-radius: 30px; font-weight:600;" />
                        </div>
                    </form>
                    <p align="center"><a href="login.php" class="text-warning" style="font-weight:600;text-decoration:none;">Back to Login</a></p>
                </div>
            </div>
        </div>
    </section>
    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"></script>
</body>

</html>
