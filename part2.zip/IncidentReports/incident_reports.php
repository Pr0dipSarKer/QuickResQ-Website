<?php
session_start();
include_once('../connection.php');

$_SESSION['name'];
$_SESSION['username'];

$conn = mysqli_connect('localhost', 'root', '', 'quickresq');


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickResQ - Incidents</title>
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="incident_report.css">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>

    <header>
        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="../EmergencyRequest/emergency_request_form.php">Need Help</a></li>
                <li><a href="incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>


    <button class="toggle-form-btn" onclick="toggleForm()">Report an Incident</button>

    <div class="reportform" id="reportForm">
        <form action="submit_report.php" method="post" enctype="multipart/form-data" onsubmit="return submitForm()">
            <h2>Report an Incident</h2>
            <label for="user_name">Your Name:</label>
            <input type="text" id="user_name" name="user_name" required>

            <label for="incident_type">Incident Type:</label>
            <input type="text" id="incident_type" name="incident_type" required>

            <label for="incident_details">Incident Details:</label>
            <textarea id="incident_details" name="incident_details" required></textarea>

            <label for="incident_pictures">Upload Pictures:</label>
            <input type="file" id="incident_pictures" name="incident_pictures[]" multiple>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>

            <button type="submit">Submit Report</button>
        </form>
    </div>


    <div id="otherContent">
        <h1 style="color:brown;">INCIDENTS</h1>
        <?php
        include_once('../connection.php');
        date_default_timezone_set('Asia/Dhaka'); // Set the timezone to Bangladesh

        $sql = "SELECT * FROM incident_reports ORDER BY date DESC";
        $result = $conn->query($sql);

        echo "<div class='report-container'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='report-card'>";
            echo "<div class='report-images'>";
            $report_id = $row['report_id'];
            $photo_sql = "SELECT photo_data FROM incident_photos WHERE report_id = $report_id";
            $photo_result = $conn->query($photo_sql);
            while ($photo_row = $photo_result->fetch_assoc()) {
                echo "<img src='data:image/jpeg;base64," . base64_encode($photo_row['photo_data']) . "' alt='Incident Picture'>";
            }
            echo "</div>";
            echo "<div class='report-details'>";
            echo "<h3>Posted By: " . htmlspecialchars($row['user_name']) . "</h3>";
            echo "<p><strong>Incident Type:</strong> " . htmlspecialchars($row['incident_type']) . "</p>";
            echo "<p><strong>Incident Details</strong> <br>" . htmlspecialchars($row['incident_details']) . "</p>";
            echo "<p><strong>Location:</strong> " . htmlspecialchars($row['location']) . "</p>";
            echo "<p><strong>Date:</strong> " . date('F j, Y g:i A', strtotime($row['date'])) . "</p>"; // Format date and time
            echo "</div>";
            echo "</div>";
        }
        echo "</div>";

        $conn->close();
        ?>

    </div>


    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email: quickresq@info.org.bd</p>
                <p>Phone: +123 456 789</p>
                <p>Address: B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>
    </footer>


    <script>
        function toggleForm() {
            const form = document.getElementById('reportForm');
            form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'flex' : 'none';
        }

        function submitForm() {
            // Form submission logic here
            // After form submission, hide the form
            setTimeout(() => {
                document.getElementById('reportForm').style.display = 'none';
            }, 500); // Timeout to allow form submission to complete
            return true; // Allow form submission to proceed
        }
    </script>

</body>

</html>