<?php
include_once('../connection.php');

$user_name = $_POST['user_name'];
$incident_type = $_POST['incident_type'];
$incident_details = $_POST['incident_details'];
$location = $_POST['location'];

// Insert the incident report
$sql = "INSERT INTO incident_reports (user_name, incident_type, incident_details, location) VALUES (?, ?, ?, ?)";
$stmt = $con->prepare($sql);
$stmt->bind_param('ssss', $user_name, $incident_type, $incident_details, $location);

if ($stmt->execute()) {
    $report_id = $stmt->insert_id;

    // Handle multiple file uploads
    foreach ($_FILES['incident_pictures']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['incident_pictures']['error'][$key] == 0) {
            $photo_data = file_get_contents($tmp_name);

            // Insert the photo data into the database
            $sql = "INSERT INTO incident_photos (report_id, photo_data) VALUES (?, ?)";
            $photo_stmt = $con->prepare($sql);
            $photo_stmt->bind_param('ib', $report_id, $photo_data);
            $photo_stmt->send_long_data(1, $photo_data);
            $photo_stmt->execute();
            $photo_stmt->close();
        }
    }

    echo "Report submitted successfully.";
} else {
    echo "Error: " . $con->error;
}

$stmt->close();
$con->close();
?>
