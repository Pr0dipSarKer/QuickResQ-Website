<?php
session_start();
include_once('../connection.php');

// if(isset($_SESSION['name']) && isset($_SESSION['username'] )){

// }
$_SESSION['name'];
$_SESSION['username'];
?>

<?php
// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'quickresq';

// Create a secure connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $address = $_POST["address"];
    $latitude = $_POST["latitude"];
    $longitude = $_POST["longitude"];
    $phoneNum = $_POST["phoneNum"];
    $website = $_POST["website"];
    $keyword = $_POST["keyword"];

    // Validate user input
    if (empty($name) || empty($address) || empty($phoneNum) || empty($website) || empty($keyword)) {
        echo "Please fill in all fields";
        exit;
    }

    // Check for duplicate entries
    $stmt = $conn->prepare("SELECT COUNT(*) FROM hospitaldatabase WHERE name = ? OR phoneNum = ? OR website = ?");
    $stmt->bind_param("sss", $name, $phoneNum, $website);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        echo "<script>
        alert('A record with similar details already exists.\\nTRY SOMETHING NEW.'); 
        setTimeout(function(){ window.location.href = 'hospital_join.php'; }, 100);
        </script>";
        exit;
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO hospitaldatabase (name, address, latitude, longitude, phoneNum, website, keyword) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("ssddsss", $name, $address, $latitude, $longitude, $phoneNum, $website, $keyword);

    // Execute the prepared statement
    if ($stmt->execute()) {
        echo "Record inserted successfully";
        header('Location: hospital_join.php');
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>QuickResQ - Hospital</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link href="hospital_join.css" rel="stylesheet" type="text/css">
    <script src="https://kit.fontawesome.com/1165876da6.js" crossorigin="anonymous"></script>
    <!-- Include Google Maps API with your API key -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places" defer></script>


</head>


<body>
    <!-- Add the top navigation here -->

    <div class="marquee">
        <span>Welcome <?= $_SESSION['name']; ?> to QuickResQ</span>
    </div>


    <header>
        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo" /></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>



        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="#">Hospital</a>
                            <ul class="sub-menu">
                                <li><a href="hospital.php">Search</a></li>
                            </ul>
                        </li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="../EmergencyRequest/emergency_request_form.php">Need Help</a></li>
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>


    </header>


    <div>
        <form action="hospital_join.php" method="post" autocomplete="off">
            <h3 class="title">Add Hospital Information</h3>

            <div class="input-container">
                <label for="">Name<span class="required">*</span></label>
                <input type="text" name="name" class="input" placeholder="e.g. Dhaka Medical College Hospital" required />
            </div>

            <div class="input-container">
                <label for="address">Address<span class="required">*</span></label>
                <input type="text" id="address" name="address" class="input" placeholder="e.g. Secretariat Road, Central Shaheed Minar Area, Shahbagh, Dhaka" required />
                <button type="button" onclick="convertAddress()">Write Your Address & Click Me<span class="required">*</span></button>
            </div>

            <div class="input-container">
                <input type="hidden" id="latitude" name="latitude" class="input" placeholder="You can read only. Its Automatically Get from the Address" required readonly />
            </div>

            <div class="input-container">
                <input type="hidden" id="longitude" name="longitude" class="input" placeholder="You can read only. Its Automatically Get from the Address" required readonly />
            </div>

            <div class="input-container">
                <label for="">Phone Number<span class="required">*</span></label>
                <input type="text" name="phoneNum" class="input" placeholder="e.g. 0123456789" required />
            </div>

            <div class="input-container">
                <label for="">Website or Social Media Link</label>
                <input type="text" name="website" class="input" placeholder="e.g. www.dmch.com.bd" />
            </div>

            <div class="input-container">
                <label for="">Keywords [separated by comma]<span class="required">*</span></label>
                <input type="text" name="keyword" class="input" placeholder="e.g. Dhaka, Puran Dhaka, Dhanmondi, Gulshan" required />
            </div>

            <input type="submit" value="Send" class="btn" name="contactus" />
        </form>
    </div>




    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email:quickresq@info.org.bd</p>
                <p>Phone:+123 456 789</p>
                <p>Address:B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>
    </footer>


    <script>
        function convertAddress() {
            var address = document.getElementById('address').value;
            var apiKey = '7bc38d22cc91438eb42f41ed38e0197f';
            var url = `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(address)}&key=${apiKey}`;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.results.length > 0) {
                        var lat = data.results[0].geometry.lat;
                        var lng = data.results[0].geometry.lng;
                        document.getElementById('latitude').value = lat;
                        document.getElementById('longitude').value = lng;
                    } else {
                        alert('Please Write Your Address then Click. \n No results found');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error fetching coordinates');
                });
        }
    </script>



</body>

</html>