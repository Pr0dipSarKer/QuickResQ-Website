<?php
session_start();
//include_once('connection.php');
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "quickresq";

if(!$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname)) {
    die("failed to connect!");
}

// Redirect to login page if session variables are not set
if (!isset($_SESSION['name']) || !isset($_SESSION['username'])) {
    header("Location: ../Login_Register/login.php");
    exit();
}

$name = $_SESSION['name']; // User's name from session
$username = $_SESSION['username']; // User's username from session

// Fetch users_id based on the session variable
$sql = "SELECT id FROM tbl_user WHERE name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $name);
$stmt->execute();
$stmt->bind_result($users_id);
$stmt->fetch();
$stmt->close();

if (empty($users_id)) {
    // Handle case where users_id is not found based on the session variable
    die("Error: User ID not found for user '$name'.");
}

$message = '';

$edit_mode = false; // Initialize $edit_mode here

// Handle form submission for adding/editing contacts
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $contact_names = $_POST['contact_name'];
    $contact_phones = $_POST['contact_phone'];
    $contact_emails = $_POST['contact_email'];
    $contact_ids = $_POST['contact_id']; // Added to handle existing contact IDs

    foreach ($contact_names as $index => $contact_name) {
        $contact_phone = $contact_phones[$index];
        $contact_email = $contact_emails[$index];

        if (!empty($contact_ids[$index])) {
            // Edit existing contact
            $contact_id = $contact_ids[$index];
            $sql = "UPDATE favorite_contacts 
                    SET contact_name = ?, contact_phone = ?, contact_email = ? 
                    WHERE contact_id = ? AND users_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('sssii', $contact_name, $contact_phone, $contact_email, $contact_id, $users_id);
        } else {
            // Add new contact
            $sql = "INSERT INTO favorite_contacts (contact_name, contact_phone, contact_email, users_id) 
                    VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('sssi', $contact_name, $contact_phone, $contact_email, $users_id);
        }

        if ($stmt->execute()) {
            $message = "Contact saved successfully.";
        } else {
            $message = "Error saving contact: " . $conn->error;
        }
        $stmt->close();
    }

    // Redirect to the same page with success message
    header("Location: favoriteContact.php?message=" . urlencode($message));
    exit();
}

// Handle deletion of contacts
if (isset($_GET['delete_contact_id'])) {
    $contact_id = $_GET['delete_contact_id'];
    $sql = "DELETE FROM favorite_contacts WHERE contact_id = ? AND users_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $contact_id, $users_id);
    if ($stmt->execute()) {
        $message = "Contact deleted successfully.";
    } else {
        $message = "Error deleting contact: " . $conn->error;
    }
    $stmt->close();

    // Redirect to the same page with success message
    header("Location: favoriteContact.php?message=" . urlencode($message));
    exit();
}

// Handle edit request
if (isset($_GET['edit_contact_id'])) {
    $edit_mode = true;
    $contact_id = $_GET['edit_contact_id'];

    $sql = "SELECT contact_name, contact_phone, contact_email FROM favorite_contacts WHERE contact_id = ? AND users_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $contact_id, $users_id);
    $stmt->execute();
    $stmt->bind_result($contact_name, $contact_phone, $contact_email);
    $stmt->fetch();
    $stmt->close();
}

// Fetch all contacts for the logged-in user
$sql = "SELECT contact_id, contact_name, contact_phone, contact_email FROM favorite_contacts WHERE users_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $users_id);
$stmt->execute();
$result = $stmt->get_result();



// SMS Alert Code 

//composer require twilio/sdk
//composer require twilio/sdk
//require_once 'vendor/autoload.php'; // Load the Twilio SDK

//use Twilio\Rest\Client;

/*$twilioSid = 'your_twilio_account_sid';
$twilioToken = 'your_twilio_auth_token';
$twilioPhoneNumber = 'your_twilio_phone_number';

$twilioClient = new Client($twilioSid, $twilioToken);

function sendEmergencyAlert($phone, $message, $twilioClient, $twilioPhoneNumber) {
    try {
        $twilioClient->messages->create(
            $phone,
            [
                'from' => $twilioPhoneNumber,
                'body' => $message
            ]
        );
        return true;
    } catch (Exception $e) {
        return false;
    }
}

if (isset($_POST['emergency'])) {
    $emergencyMessage = "Emergency! Please contact " . $name . " immediately.";

    $sql = "SELECT contact_phone FROM favorite_contacts WHERE users_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $users_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $phone = $row['contact_phone'];
        sendEmergencyAlert($phone, $emergencyMessage, $twilioClient, $twilioPhoneNumber);
    }

    $stmt->close();
    header("Location: favoriteContact.php?message=" . urlencode("Emergency alerts sent successfully."));
    exit();
}*/
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickResQ - Favorite Contacts</title>
    <link rel="icon" href="../Image/QuickResQ_icon.png" type="image/x-icon" />
    <link rel="stylesheet" href="favoriteContact.css">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <script>
        function addContact() {
            const contactCount = document.querySelectorAll('.contact').length + 1;
            const contactDiv = document.createElement('div');
            contactDiv.className = 'contact';
            contactDiv.innerHTML = `
                <input type="hidden" name="contact_id[]">
                <label for="contact_name_${contactCount}">Contact Name</label>
                <input type="text" id="contact_name_${contactCount}" name="contact_name[]" required>
                
                <label for="contact_phone_${contactCount}">Contact Phone</label>
                <input type="text" id="contact_phone_${contactCount}" name="contact_phone[]" required>
                
                <label for="contact_email_${contactCount}">Contact Email</label>
                <input type="email" id="contact_email_${contactCount}" name="contact_email[]" required>
            `;
            document.getElementById('emergency-contacts').appendChild(contactDiv);
        }

        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const message = urlParams.get('message');
            if (message) {
                alert(message);
                window.location.href = window.location.pathname; // Remove query parameters
            }
        };
    </script>
</head>

<body>
    <div class="marquee">
        <span>Welcome <?= $name; ?> to QuickResQ</span>
    </div>

    <header>
        <div class="logo">
            <a href="../index.php"><img src="../Image/QuickResQ_logo.png" class="logo" alt="My Logo"></a>
            <img src="../Image/bangladesh_flag.jpg" class="flag" alt="Bangladesh Flag">
        </div>

        <div id="buttonStyle">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../whentouse.php">When to Use?</a></li>
                <li><a href="#">Services</a>
                    <ul>
                        <li><a href="../Hospital/hospital.php">Hospital</a></li>
                        <li><a href="../Ambulance/ambulance.php">Ambulance</a></li>
                        <li><a href="../Blood/blood.php">Blood</a></li>
                        <li><a href="../PoliceStation/police.php">Police Station</a></li>
                        <li><a href="../FireService/fireService.php">Fire Services</a></li>
                        <li><a href="../Volunteer/volunteer.php">Volunteer</a></li>
                        <li><a href="../Fastaid/fastaid.php">First Aid Guide</a></li>
                    </ul>
                </li>
                <li><a href="../EmergencyRequest/emergency_request_form.php">Need Help</a>
                    <ul>
                        <li><a href="../EmergencyRequest/view_requests.php">View Request</a></li>
                        <li><a href="../EmergencyRequest/map.php">See Helper</a></li>
                        <li><a href="favoriteContact.php">Contacts</a></li>
                    </ul>
                </li>
                <li><a href="../IncidentReports/incident_reports.php">Incidents</a></li>
                <li><a href="../mobileapp.php">Mobile App</a></li>
                <li><a href="#">About</a>
                    <ul>
                        <li><a href="../aboutus.php">About Us</a></li>
                        <li><a href="../ContactUs/contactus.php">Contact Us</a></li>
                        <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                    </ul>
                </li>
                <li id="logout"><a href="../Login_Register/logout.php"><img src="../Image/logout.png" class="logout" alt="logout"></a></li>
            </ul>
        </div>
    </header>

    <h1>Favorite Contacts</h1>

    <form method="POST" action="">
        <div id="emergency-contacts">
            <?php if ($edit_mode) : ?>
                <div class="contact">
                    <input type="hidden" name="contact_id[]" value="<?= $contact_id; ?>">
                    <label for="contact_name_1">Contact Name</label>
                    <input type="text" id="contact_name_1" name="contact_name[]" value="<?= htmlspecialchars($contact_name); ?>" required>

                    <label for="contact_phone_1">Contact Phone</label>
                    <input type="text" id="contact_phone_1" name="contact_phone[]" value="<?= htmlspecialchars($contact_phone); ?>" required>

                    <label for="contact_email_1">Contact Email</label>
                    <input type="email" id="contact_email_1" name="contact_email[]" value="<?= htmlspecialchars($contact_email); ?>" required>
                </div>
            <?php endif; ?>
        </div>
        <button type="button" onclick="addContact()">Add Favorite Contact</button>
        <button type="submit"><?= $edit_mode ? 'Update Contact' : 'Add Contact'; ?></button>
        <button type="submit" name="emergency">Emergency Alert</button>

    </form>

    <h2 style="margin-top: 50px; text-align:center; color:brown">You Favorite Contact List</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) : ?>
            <tr>
                <td><?= htmlspecialchars($row['contact_name']); ?></td>
                <td><?= htmlspecialchars($row['contact_phone']); ?></td>
                <td><?= htmlspecialchars($row['contact_email']); ?></td>
                <td>
                    <a href="?edit_contact_id=<?= $row['contact_id']; ?>">Edit</a> |
                    <a href="?delete_contact_id=<?= $row['contact_id']; ?>" onclick="return confirm('Are you sure you want to delete this contact?');">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <h3>Contact Us</h3>
                <p>Email: quickresq@info.org.bd</p>
                <p>Phone: +123 456 789</p>
                <p>Address: B/7, Gulshan 2, Dhaka 1212</p>
            </div>
            <div class="footer-content">
                <h3>Quick Links</h3>
                <ul class="list">
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../aboutus.php">About Us</a></li>
                    <li><a href="../mobileapp.php">Mobile App</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <li><a href="../User_Review&Rating/index.php">Reviews</a></li>
                </ul>
            </div>
            <div class="footer-content">
                <h3>Follow Us</h3>
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/joy.pal.hazard"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/JoyPal_hazard"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.instagram.com/joy__hazard/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/joy-pal-hazard/"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
            <button class="go-top" onclick="scrollToTop()">Go to Top</button>
            <script>
                function scrollToTop() {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            </script>
        </div>
        <div class="bottom-bar">
            <p>
                <a href="../footer_assets/privacy_policy.html">Privacy Policy</a> ||
                <a href="../footer_assets/copywrite_policy.html">Copyright Policy</a> ||
                <a href="../footer_assets/terms&conditions.html">Terms & Conditions</a> ||
                &copy; 2024 QuickResQ. All rights reserved.
            </p>
        </div>
    </footer>
</body>

</html>

<?php
$conn->close();
?>
